'use client';

import React, { useState, useEffect } from 'react';
import Preloader from '@/components/Preloader';
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import ProfileSection from '@/components/ProfileSection';
import CapabilitiesSection from '@/components/CapabilitiesSection';
import AiSpecializationSection from '@/components/AiSpecializationSection';
import TimelineSection from '@/components/TimelineSection';
import EducationSection from '@/components/EducationSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

export default function Home() {
  const [loading, setLoading] = useState(true);
  const [lang, setLang] = useState<'pt' | 'en'>('pt');
  const [autostart, setAutostart] = useState(false);

  useEffect(() => {
    // Check if ?autostart=1 query param is present to skip intro immediately for fast automated checks
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('autostart') === '1') {
        setAutostart(true);
        setLoading(false);
      }
    }
  }, []);

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'pt' ? 'en' : 'pt'));
  };

  return (
    <div className="min-h-screen bg-[#050508] text-zinc-100 flex flex-col relative selection:bg-[#ff1e38] selection:text-white">
      {/* Cinematic Loading Effect inspired by Reference Image 2 (Night Market) */}
      {loading && (
        <Preloader
          onComplete={() => setLoading(false)}
          autostart={autostart}
        />
      )}

      {/* Main Portfolio Page Structure inspired by Reference Image 1 (Pixel Paragon / The Finals) */}
      <Navbar currentLang={lang} onToggleLang={toggleLanguage} />

      <main className="flex-1">
        {/* Hero Section */}
        <HeroSection currentLang={lang} />

        {/* 01 // Profile Section */}
        <ProfileSection currentLang={lang} />

        {/* 02 // Capabilities & ERP Model Section */}
        <CapabilitiesSection currentLang={lang} />

        {/* AI // Specialization & Gotham Project Section */}
        <AiSpecializationSection currentLang={lang} />

        {/* 03 // Timeline & Remote Experience Section */}
        <TimelineSection currentLang={lang} />

        {/* 04 // Education & MBA Section */}
        <EducationSection currentLang={lang} />

        {/* 05 // Transmit Information / Contact Section */}
        <ContactSection currentLang={lang} />
      </main>

      {/* Footer */}
      <Footer currentLang={lang} />
    </div>
  );
}
