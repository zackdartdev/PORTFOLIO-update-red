import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Zack Enterprise Studios | Analista de TI & Operações Estratégicas',
  description: 'Isaac Lamego - Articulando inteligência de dados, engenharia de software, sólidos fundamentos jurídicos e gestão administrativa para escalar operações corporativas.',
  openGraph: {
    title: 'Zack Enterprise Studios | Isaac Lamego',
    description: 'Analista de TI & Operações Estratégicas - Portfólio Executivo & Tecnológico.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Zack Enterprise Studios | Isaac Lamego',
    description: 'TI Orientada a Gestão Empresarial, BI e Análise de Risco.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" className="dark scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Chakra+Petch:ital,wght@0,400;0,600;0,700;1,700&family=Rajdhani:wght@500;600;700&family=Space+Grotesk:wght@400;500;600;700&family=Teko:wght@500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#050508] text-zinc-100 antialiased selection:bg-[#ff1e38] selection:text-white overflow-x-hidden font-sans" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}

