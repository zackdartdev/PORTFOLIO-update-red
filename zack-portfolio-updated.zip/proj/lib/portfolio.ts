export interface ErpModuleData {
  id: string;
  name: string;
  vendor: string;
  sysLogic: string;
  architecture: string;
  apiStatus: string;
  processMapping: string;
  modules: string[];
}

export const ERP_SYSTEMS: Record<string, ErpModuleData> = {
  protheus: {
    id: 'protheus',
    name: 'Protheus',
    vendor: 'TOTVS',
    sysLogic: 'SYS_LOGIC : Protheus',
    architecture: 'Mapeamento lógico de fluxo de faturamento, estoque e contabilidade. Integração segura de APIs para redução de redundâncias operacionais.',
    apiStatus: 'REST / SOAP Verified',
    processMapping: 'Fiscal & Inventory Flows Mapped',
    modules: ['Faturamento (SIGAFAT)', 'Estoque/Custos (SIGAEST)', 'Contabilidade Gerencial (SIGACTB)', 'Compras (SIGACOM)'],
  },
  tasy: {
    id: 'tasy',
    name: 'Tasy',
    vendor: 'Philips Clinical Informatics',
    sysLogic: 'SYS_LOGIC : Tasy EMR/ERP',
    architecture: 'Parametrização de prontuário eletrônico integrado à cadeia de suprimentos hospitalar, faturamento TISS/TUSS e auditoria médica.',
    apiStatus: 'HL7 / FHIR / REST Native',
    processMapping: 'Clinical & Billing Workflows',
    modules: ['Faturamento Convênios (TISS)', 'Farmácia Central & Dispensação', 'Prontuário Eletrônico', 'Auditoria de Contas'],
  },
  senior: {
    id: 'senior',
    name: 'Senior ERP',
    vendor: 'Senior Sistemas',
    sysLogic: 'SYS_LOGIC : Senior Gestão Empresarial (ERP)',
    architecture: 'Estrutura robusta de Gestão de Pessoas (HCM), folha de pagamento, compliance fiscal e gestão industrial com regras de negócio customizadas via LSP.',
    apiStatus: 'Web Services / REST / SGI',
    processMapping: 'HCM, Tax & Supply Chain',
    modules: ['Gestão de Pessoas (HCM)', 'Controladoria & Finanças', 'Mercado & Vendas', 'Suprimentos & Logística'],
  },
  '4medic': {
    id: '4medic',
    name: '4medic',
    vendor: '4medic Healthcare SaaS',
    sysLogic: 'SYS_LOGIC : 4medic Clinic Suite',
    architecture: 'Modelagem ágil de fluxos ambulatoriais, agenda médica multi-unidade, telemedicina e conformidade com LGPD para dados sensíveis em saúde.',
    apiStatus: 'RESTful Microservices & Webhooks',
    processMapping: 'Patient Journey & Outpatient Billing',
    modules: ['Agenda Médica Inteligente', 'Prescrição Digital & CFM', 'Financeiro & Split de Pagamentos', 'Segurança LGPD'],
  },
};

export function getErpSystem(id: string): ErpModuleData {
  return ERP_SYSTEMS[id] || ERP_SYSTEMS.protheus;
}

export interface ContactPayload {
  name: string;
  email?: string;
  serviceFocus: string;
  budget?: string;
  notes?: string;
}

export function formatWhatsAppMessage(payload: ContactPayload): string {
  const cleanName = payload.name.trim() || 'Parceiro Comercial';
  const service = payload.serviceFocus.trim() || 'BI, Data & Business Analytics';
  const budget = payload.budget ? ` | Orçamento Estimado: ${payload.budget}` : '';
  const email = payload.email ? ` | Email: ${payload.email}` : '';
  const notes = payload.notes ? `\n\nDetalhes:\n${payload.notes}` : '';

  const raw = `Olá Isaac (ZACK STUDIOS), meu nome é ${cleanName}.\nTenho interesse em iniciar um diálogo sobre: ${service}.${budget}${email}${notes}`;
  return `https://wa.me/5521990315582?text=${encodeURIComponent(raw)}`;
}

export function calculateSummaryMetrics() {
  return [
    { value: '100%', label: 'Operação Remota Segura', detail: 'Conexão criptografada, conformidade internacional' },
    { value: '30+', label: 'Empresas Atendidas', detail: 'EUA, Suíça, Alemanha, França, Portugal e Brasil' },
    { value: 'R$ 75k', label: 'Orçamento Único de Projetos', detail: 'Defesa e formatação técnica de alta complexidade' },
  ];
}

export const AI_TECH_STACK = {
  localModels: ['Qwen 2.5', 'Ollama', 'LM Studio'],
  orchestration: ['Claude Code', 'Claude Cowork', 'Codex', 'Microsoft Copilot Studio', 'Automações de fluxos'],
  generative: ['IA Generativa', 'Machine Learning', 'LLMs para tomada de decisão', 'Tratamento de dados'],
  deepening: [
    'Engenharia de prompts avançada',
    'Saídas estruturadas (JSON) e tool use',
    'RAG e embeddings',
    'Bancos vetoriais',
    'MCP (Model Context Protocol)',
    'Avaliação de respostas (evals)',
    'Quantização de modelos (GGUF)',
    'Python e pandas',
    'Hugging Face',
  ],
};
