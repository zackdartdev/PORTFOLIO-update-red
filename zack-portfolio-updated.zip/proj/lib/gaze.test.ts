import test from 'node:test';
import assert from 'node:assert/strict';
import {
  GAZE_POSES,
  GAZE_TUNING,
  GAZE_VIDEO,
  frameIndex,
  frameTime,
  getPose,
  pickPose,
  pointerToGaze,
  tweenDuration,
} from './gaze.ts';

const rest = () => getPose(GAZE_VIDEO.restPoseId);

test('todas as poses ficam dentro da duração do vídeo e têm ids únicos', () => {
  const ids = new Set<string>();
  for (const p of GAZE_POSES) {
    assert.ok(p.t >= 0 && p.t < GAZE_VIDEO.duration, `${p.id} fora do vídeo`);
    assert.ok(Math.abs(p.yaw) <= 1 && Math.abs(p.pitch) <= 1, `${p.id} fora de -1..1`);
    assert.ok(!ids.has(p.id), `id duplicado ${p.id}`);
    ids.add(p.id);
  }
  assert.ok(ids.has(GAZE_VIDEO.restPoseId));
});

test('pointerToGaze aplica zona morta, limite e sinal', () => {
  assert.deepEqual(pointerToGaze(0.03, -0.03), { yaw: 0, pitch: 0 });
  assert.equal(pointerToGaze(5, 0).yaw, 1);
  assert.equal(pointerToGaze(-5, 0).yaw, -1);
  assert.ok(pointerToGaze(0.5, 0).yaw > 0);
  assert.ok(pointerToGaze(0, 0.5).pitch > 0);
});

test('cursor à direita/esquerda escolhe poses com yaw correspondente', () => {
  const right = pickPose({ yaw: 1, pitch: 0 }, rest());
  const left = pickPose({ yaw: -1, pitch: 0 }, rest());
  assert.ok(right.yaw > 0.8, `direita escolheu ${right.id}`);
  assert.ok(left.yaw < -0.8, `esquerda escolheu ${left.id}`);
});

test('cursor no centro mantém a pose de repouso', () => {
  assert.equal(pickPose({ yaw: 0, pitch: 0 }, rest()).id, GAZE_VIDEO.restPoseId);
});

test('a direita, a partir do repouso, não exige troca de segmento', () => {
  const right = pickPose({ yaw: 1, pitch: 0 }, rest());
  assert.equal(right.segment, rest().segment);
});

test('olhar para baixo e para cima usa poses com pitch coerente', () => {
  const down = pickPose({ yaw: 0, pitch: -1 }, rest());
  assert.ok(down.pitch < rest().pitch, `baixo escolheu ${down.id}`);
  const upRight = pickPose({ yaw: 0.9, pitch: 1 }, rest());
  assert.ok(upRight.pitch > 0, `cima-direita escolheu ${upRight.id}`);
});

test('histerese evita trocar de pose por pequenas variações', () => {
  const start = pickPose({ yaw: 1, pitch: 0 }, rest());
  const again = pickPose({ yaw: 0.97, pitch: 0.02 }, start);
  assert.equal(again.id, start.id);
});

test('tweenDuration respeita limites', () => {
  assert.equal(tweenDuration(1, 1.01), GAZE_TUNING.minTweenSeconds);
  assert.equal(tweenDuration(0, 8), GAZE_TUNING.maxTweenSeconds);
});

test('frameTime cai no meio do quadro e nunca passa do fim', () => {
  assert.equal(frameIndex(frameTime(7.0)), 168);
  assert.ok(frameTime(100) < GAZE_VIDEO.duration);
  assert.ok(frameTime(-3) > 0);
});
