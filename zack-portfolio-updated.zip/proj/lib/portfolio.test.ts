import test from 'node:test';
import assert from 'node:assert/strict';
import {
  ERP_SYSTEMS,
  getErpSystem,
  formatWhatsAppMessage,
  calculateSummaryMetrics,
  AI_TECH_STACK,
} from './portfolio.ts';

test('ERP_SYSTEMS contains all 4 key enterprise ERP suites', () => {
  assert.ok(ERP_SYSTEMS.protheus);
  assert.ok(ERP_SYSTEMS.tasy);
  assert.ok(ERP_SYSTEMS.senior);
  assert.ok(ERP_SYSTEMS['4medic']);
  assert.equal(ERP_SYSTEMS.protheus.apiStatus, 'REST / SOAP Verified');
});

test('getErpSystem returns requested system or falls back to protheus', () => {
  const tasy = getErpSystem('tasy');
  assert.equal(tasy.name, 'Tasy');

  const fallback = getErpSystem('unknown-system');
  assert.equal(fallback.name, 'Protheus');
});

test('formatWhatsAppMessage builds valid WhatsApp URL with encoded params', () => {
  const url = formatWhatsAppMessage({
    name: 'Isaac Lamego',
    serviceFocus: 'BI & ERP Integration',
    budget: 'R$ 75k',
    email: 'test@example.com',
    notes: 'Prioridade alta para implantação.',
  });

  assert.ok(url.startsWith('https://wa.me/5521990315582?text='));
  assert.ok(url.includes('Isaac%20Lamego'));
  assert.ok(url.includes('BI%20%26%20ERP%20Integration'));
  assert.ok(url.includes('R%24%2075k'));
});

test('calculateSummaryMetrics returns exactly 3 core metrics with non-empty fields', () => {
  const metrics = calculateSummaryMetrics();
  assert.equal(metrics.length, 3);
  assert.equal(metrics[0].value, '100%');
  assert.equal(metrics[1].value, '30+');
  assert.equal(metrics[2].value, 'R$ 75k');
});

test('AI_TECH_STACK exposes Qwen, Ollama, and Claude tooling', () => {
  assert.ok(AI_TECH_STACK.localModels.includes('Ollama'));
  assert.ok(AI_TECH_STACK.orchestration.includes('Claude Code'));
  assert.ok(AI_TECH_STACK.deepening.includes('MCP (Model Context Protocol)'));
});
