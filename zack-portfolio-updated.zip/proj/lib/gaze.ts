/**
 * Configuração e lógica pura do personagem em vídeo que acompanha o cursor com o olhar.
 *
 * >>> ÚNICO LOCAL PARA AJUSTAR OS TIMESTAMPS DO VÍDEO <<<
 * Edite `GAZE_POSES` abaixo. Cada pose diz: "neste instante `t` (segundos) do vídeo,
 * o personagem está olhando para (yaw, pitch)".
 *
 *  - yaw   : -1 = olha para a ESQUERDA da tela, 0 = centro, +1 = olha para a DIREITA
 *  - pitch : -1 = olha para BAIXO,              0 = neutro, +1 = olha para CIMA
 *  - segment: trechos do vídeo em que o movimento da cabeça é contínuo e monótono.
 *             Dentro do mesmo segmento o vídeo é "arrastado" (scrub) entre as poses,
 *             o que reproduz o giro real da cabeça. Entre segmentos diferentes o
 *             vídeo faz um corte suave (crossfade), para nunca passar por poses erradas.
 *
 * O vídeo fonte (operator-gaze.mp4/webm) tem 24 fps e ~8,04 s. Mapa do material:
 *   0.25–0.50  cabeça virada p/ a direita, levemente para cima
 *   1.00–1.55  cabeça desce enquanto gira da direita para a esquerda
 *   2.00–2.50  cabeça virada p/ a esquerda
 *   3.00       esquerda/baixo  →  3.50–4.50 direita
 *   4.50–5.40  direita → centro (cabeça baixa)
 *   6.00–7.60  centro (6.25 levemente à esquerda, 7.60 cabeça mais baixa)
 */

export interface GazePose {
  id: string;
  /** segundos no vídeo */
  t: number;
  yaw: number;
  pitch: number;
  segment: number;
}

export const GAZE_VIDEO = {
  sources: [
    { src: '/video/operator-gaze.mp4', type: 'video/mp4' },
    { src: '/video/operator-gaze.webm', type: 'video/webm; codecs="vp9"' },
  ],
  poster: '/video/operator-poster.jpg',
  fps: 24,
  duration: 8.0416,
  /** proporção do vídeo recortado (largura / altura) */
  aspect: 1120 / 1080,
  /** pose exibida antes de qualquer interação */
  restPoseId: 'center',
} as const;

export const GAZE_POSES: readonly GazePose[] = [
  // Segmento 1 — varredura direita → esquerda (com a cabeça baixando no meio)
  { id: 'right-up', t: 0.35, yaw: 0.9, pitch: 0.3, segment: 1 },
  { id: 'right-down', t: 1.0, yaw: 0.45, pitch: -0.55, segment: 1 },
  { id: 'center-down-a', t: 1.25, yaw: -0.15, pitch: -0.65, segment: 1 },
  { id: 'left-down', t: 1.6, yaw: -0.6, pitch: -0.5, segment: 1 },
  { id: 'left', t: 2.1, yaw: -0.9, pitch: 0.0, segment: 1 },
  { id: 'left-up', t: 2.4, yaw: -1.0, pitch: 0.25, segment: 1 },

  // Segmento 2 — esquerda/baixo → direita
  { id: 'left-down-b', t: 3.0, yaw: -0.7, pitch: -0.55, segment: 2 },
  { id: 'right-b', t: 3.85, yaw: 1.0, pitch: 0.0, segment: 2 },

  // Segmento 3 — direita → centro
  { id: 'right-c', t: 4.4, yaw: 1.0, pitch: -0.1, segment: 3 },
  { id: 'center-low', t: 5.4, yaw: 0.0, pitch: -0.5, segment: 3 },
  { id: 'center-left', t: 6.25, yaw: -0.3, pitch: -0.35, segment: 3 },
  { id: 'center', t: 7.0, yaw: 0.0, pitch: -0.15, segment: 3 },
  { id: 'center-down-c', t: 7.6, yaw: 0.0, pitch: -0.75, segment: 3 },
];

export const GAZE_TUNING = {
  /** zona morta no centro (fração de -1..1) para o olhar não tremer */
  deadZone: 0.06,
  /** peso de cada eixo na escolha da pose mais próxima */
  yawWeight: 1,
  pitchWeight: 0.55,
  /** custo extra para trocar de segmento (corte com crossfade) */
  hopPenalty: 0.15,
  /** só troca de pose se a nova for melhor que a atual por esta margem (evita flicker) */
  hysteresis: 0.08,
  /** duração do tween = distância no vídeo (s) * este fator, limitada abaixo */
  secondsPerVideoSecond: 0.38,
  minTweenSeconds: 0.22,
  maxTweenSeconds: 0.9,
  /** duração do crossfade entre segmentos */
  crossfadeSeconds: 0.2,
  /** tempo máximo esperando o seek do vídeo reserva antes de desistir do corte */
  hopSeekTimeoutMs: 600,
} as const;

export type GazeTuning = typeof GAZE_TUNING;

export interface Gaze {
  yaw: number;
  pitch: number;
}

const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));

/**
 * Converte a posição do cursor, normalizada pela área de interação (-1..1 em x e y,
 * com y positivo para CIMA), em uma direção de olhar.
 */
export function pointerToGaze(nx: number, ny: number, deadZone: number = GAZE_TUNING.deadZone): Gaze {
  const soften = (v: number) => {
    const c = clamp(v, -1, 1);
    const a = Math.abs(c);
    if (a <= deadZone) return 0;
    return Math.sign(c) * ((a - deadZone) / (1 - deadZone));
  };
  return { yaw: soften(nx), pitch: soften(ny) };
}

/** Escolhe a pose do vídeo que melhor representa o olhar desejado, com histerese. */
export function pickPose(
  gaze: Gaze,
  current: GazePose,
  poses: readonly GazePose[] = GAZE_POSES,
  tuning: GazeTuning = GAZE_TUNING
): GazePose {
  const cost = (p: GazePose) =>
    Math.hypot((p.yaw - gaze.yaw) * tuning.yawWeight, (p.pitch - gaze.pitch) * tuning.pitchWeight) +
    (p.segment !== current.segment ? tuning.hopPenalty : 0);

  let best = current;
  let bestCost = cost(current);
  for (const p of poses) {
    const c = cost(p);
    if (c < bestCost) {
      best = p;
      bestCost = c;
    }
  }
  if (best === current) return current;
  return bestCost > cost(current) - tuning.hysteresis ? current : best;
}

/** Duração do tween de scrub entre duas posições do vídeo. */
export function tweenDuration(fromT: number, toT: number, tuning: GazeTuning = GAZE_TUNING): number {
  return clamp(Math.abs(toT - fromT) * tuning.secondsPerVideoSecond, tuning.minTweenSeconds, tuning.maxTweenSeconds);
}

/** Quantiza um instante para o meio do quadro correspondente (evita seeks entre quadros). */
export function frameTime(t: number, fps: number = GAZE_VIDEO.fps, duration: number = GAZE_VIDEO.duration): number {
  return clamp((frameIndex(t, fps) + 0.5) / fps, 0.5 / fps, duration - 0.5 / fps);
}

/** Índice do quadro mostrado em `t`, usado para não repetir seeks no mesmo quadro. */
export function frameIndex(t: number, fps: number = GAZE_VIDEO.fps): number {
  return Math.floor(t * fps + 1e-6);
}

export function getPose(id: string, poses: readonly GazePose[] = GAZE_POSES): GazePose {
  const found = poses.find((p) => p.id === id);
  if (!found) throw new Error(`Pose de olhar desconhecida: ${id}`);
  return found;
}
