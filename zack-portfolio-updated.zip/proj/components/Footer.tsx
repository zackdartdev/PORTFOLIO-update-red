'use client';

import React from 'react';
import { Shield, ArrowUp, Terminal, Phone, Globe } from 'lucide-react';

interface FooterProps {
  currentLang: 'pt' | 'en';
}

export default function Footer({ currentLang }: FooterProps) {
  const isPt = currentLang === 'pt';

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-[#040407] border-t border-zinc-900 pt-16 pb-12 text-zinc-400 font-tech">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-zinc-900">
          
          {/* Brand & Mission Column */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <span className="font-display text-3xl font-bold tracking-tight text-white">
                ZACK <span className="text-[#ff1e38]">ENGINE</span>
              </span>
              <span className="px-2 py-0.5 text-[9px] font-tech font-bold uppercase tracking-widest bg-red-950/70 text-[#ff334b] border border-red-500/40 rounded-xs">
                SECURE REMOTE
              </span>
            </div>

            <p className="font-body text-xs sm:text-sm text-zinc-400 max-w-sm leading-relaxed">
              {isPt
                ? 'Operando na interseção entre tecnologia, gestão administrativa e automações de alto valor.'
                : 'Operating at the intersection of technology, administrative governance, and high-yield automation.'}
            </p>

            <div className="text-[11px] text-zinc-500">
              © 2026 ZACKFILMS Inc. // Secure Remote Network.<br />
              {isPt ? 'Todos os direitos reservados.' : 'All rights reserved.'}
            </div>
          </div>

          {/* Navigation Coordinates */}
          <div className="lg:col-span-3 flex flex-col gap-3">
            <div className="text-xs font-bold text-white tracking-widest uppercase mb-1">
              COORDINATES
            </div>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#sobre" className="hover:text-[#ff1e38] transition-colors">
                  {isPt ? 'SOBRE MIM' : 'ABOUT ME'}
                </a>
              </li>
              <li>
                <a href="#especialidades" className="hover:text-[#ff1e38] transition-colors">
                  {isPt ? 'Especialidades & ERPs' : 'Capabilities & ERPs'}
                </a>
              </li>
              <li>
                <a href="#ia" className="hover:text-[#ff1e38] transition-colors">
                  {isPt ? 'Inteligência Artificial (Gotham)' : 'Artificial Intelligence'}
                </a>
              </li>
              <li>
                <a href="#experiencia" className="hover:text-[#ff1e38] transition-colors">
                  {isPt ? 'Experiência Profissional' : 'Experience'}
                </a>
              </li>
              <li>
                <a href="#formacao" className="hover:text-[#ff1e38] transition-colors">
                  {isPt ? 'Formação & MBA' : 'Education & MBA'}
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-[#ff1e38] transition-colors">
                  {isPt ? 'Contato Direto' : 'Direct Contact'}
                </a>
              </li>
            </ul>
          </div>

          {/* System Diagnostics & Contacts */}
          <div className="lg:col-span-4 flex flex-col gap-3">
            <div className="text-xs font-bold text-white tracking-widest uppercase mb-1 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-[#ff1e38]" />
              <span>SYSTEM DIAGNOSTICS</span>
            </div>

            <div className="p-3.5 bg-zinc-950/80 border border-zinc-800 rounded-xs space-y-1.5 text-[11px] font-mono">
              <div className="flex justify-between">
                <span className="text-zinc-500">STATUS:</span>
                <span className="text-green-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full shadow-[0_0_6px_#22c55e]" />
                  SECURE & ENCRYPTED
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">IP:</span>
                <span className="text-zinc-300">LOCALHOST // 127.0.0.1</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">LANG:</span>
                <span className="text-zinc-300">PORTUGUÊS / ENGLISH</span>
              </div>
              <div className="pt-2 border-t border-zinc-900 text-zinc-400">
                <div className="text-zinc-500 text-[10px] uppercase">COMMUNICATION LINES:</div>
                <div className="text-zinc-200">+55 21 99031-5582</div>
                <div className="text-zinc-200">+55 21 97088-6158</div>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar with Back to Top */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-[#ff1e38]" />
            <span>ZACK ENTERPRISE STUDIOS // AIR-GAPPED DECISION SUITE</span>
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer group"
          >
            <span>BACK TO TOP</span>
            <ArrowUp className="w-3.5 h-3.5 transition-transform group-hover:-translate-y-0.5 text-[#ff1e38]" />
          </button>
        </div>
      </div>
    </footer>
  );
}
