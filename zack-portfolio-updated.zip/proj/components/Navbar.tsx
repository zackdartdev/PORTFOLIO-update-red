'use client';

import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, MessageSquare, ShieldCheck, Globe } from 'lucide-react';

interface NavbarProps {
  currentLang: 'pt' | 'en';
  onToggleLang: () => void;
}

export default function Navbar({ currentLang, onToggleLang }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: currentLang === 'pt' ? 'SOBRE' : 'ABOUT', href: '#sobre' },
    { label: currentLang === 'pt' ? 'ESPECIALIDADES' : 'CAPABILITIES', href: '#especialidades' },
    { label: 'IA', href: '#ia' },
    { label: currentLang === 'pt' ? 'EXPERIÊNCIA' : 'EXPERIENCE', href: '#experiencia' },
    { label: currentLang === 'pt' ? 'FORMAÇÃO' : 'EDUCATION', href: '#formacao' },
    { label: currentLang === 'pt' ? 'CONTATO' : 'CONTACT', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#060609]/90 backdrop-blur-md border-b border-zinc-800/80 py-3 shadow-lg shadow-black/50'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo - inspired by PIXEL PARAGON reference */}
        <a href="#" className="flex items-center gap-3 group">
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white group-hover:text-[#ff1e38] transition-colors">
                ZACK <span className="text-[#ff1e38]">STUDIOS</span>
              </span>
              <span className="px-1.5 py-0.5 text-[9px] font-tech font-bold uppercase tracking-widest bg-red-950/70 text-[#ff334b] border border-red-500/40 rounded-xs">
                IT & ADMIN OPS
              </span>
            </div>
            <span className="text-[10px] font-tech tracking-[0.2em] text-zinc-500 uppercase">
              ENTERPRISE INTELLIGENCE
            </span>
          </div>
        </a>

        {/* Center Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 font-tech text-xs tracking-widest font-semibold text-zinc-300">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="hover:text-[#ff1e38] transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#ff1e38] hover:after:w-full after:transition-all"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Right CTA Area & Language Switch */}
        <div className="hidden lg:flex items-center gap-4">
          {/* Language Toggle */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-tech text-zinc-400 hover:text-white border border-zinc-800 hover:border-zinc-700 bg-zinc-900/60 rounded-xs transition-colors cursor-pointer"
            aria-label="Alternar idioma"
          >
            <Globe className="w-3 h-3 text-[#ff1e38]" />
            <span className="font-bold">{currentLang.toUpperCase()}</span>
          </button>

          {/* Primary Action Button (Red) - inspired by START A PROJECT in Reference 1 */}
          <a
            href="https://wa.me/5521990315582?text=Ol%C3%A1%20Isaac%2C%20gostaria%20de%20iniciar%20um%20di%C3%A1logo%20executivo."
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-2 px-5 py-2.5 bg-[#ff1e38] hover:bg-[#ff334b] text-white font-tactical font-bold text-xs tracking-widest uppercase transition-all shadow-[0_0_20px_rgba(255,30,56,0.4)] hover:shadow-[0_0_28px_rgba(255,30,56,0.65)] rounded-xs"
          >
            <MessageSquare className="w-3.5 h-3.5 fill-current" />
            <span>CONVERSAR NO WHATSAPP</span>
            <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex items-center gap-3 md:hidden">
          <button
            onClick={onToggleLang}
            className="px-2 py-1 text-[11px] font-tech text-zinc-300 border border-zinc-800 bg-zinc-900/80 rounded-xs"
          >
            {currentLang.toUpperCase()}
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-zinc-400 hover:text-white border border-zinc-800 bg-zinc-900/60 rounded-xs"
            aria-label="Abrir menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6 text-[#ff1e38]" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#07070b]/98 border-b border-red-500/30 px-6 py-6 font-tech">
          <div className="flex flex-col gap-4 text-sm font-semibold tracking-widest text-zinc-300">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="py-2 border-b border-zinc-900 hover:text-[#ff1e38] transition-colors flex items-center justify-between"
              >
                <span>{link.label}</span>
                <ArrowUpRight className="w-4 h-4 text-zinc-600" />
              </a>
            ))}

            <div className="pt-4 flex flex-col gap-3">
              <a
                href="https://wa.me/5521990315582?text=Ol%C3%A1%20Isaac%2C%20gostaria%20de%20iniciar%20um%20di%C3%A1logo%20executivo."
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full py-3 bg-[#ff1e38] text-white font-tactical font-bold text-xs tracking-widest uppercase rounded-xs shadow-[0_0_20px_rgba(255,30,56,0.4)]"
              >
                <MessageSquare className="w-4 h-4" />
                <span>CONVERSAR NO WHATSAPP</span>
              </a>

              <a
                href="#contato"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-center gap-2 w-full py-3 bg-zinc-900 border border-zinc-700 text-zinc-200 font-tactical font-bold text-xs tracking-widest uppercase rounded-xs"
              >
                <span>ENTRAR EM CONTATO AGORA</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
