'use client';

import React, { useState } from 'react';
import {
  Mail,
  Phone,
  MessageSquare,
  ShieldAlert,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Send,
  Lock,
  Copy,
  Check,
} from 'lucide-react';
import { formatWhatsAppMessage } from '@/lib/portfolio';

interface ContactSectionProps {
  currentLang: 'pt' | 'en';
}

export default function ContactSection({ currentLang }: ContactSectionProps) {
  const isPt = currentLang === 'pt';

  // 2-step interactive form state
  const [step, setStep] = useState<1 | 2>(1);
  const [name, setName] = useState('');
  const [serviceFocus, setServiceFocus] = useState('BI, Data & Business Analytics');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [budget, setBudget] = useState('R$ 20k - R$ 75k');
  const [notes, setNotes] = useState('');
  const [copiedEmail, setCopiedEmail] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const serviceOptions = [
    'BI, Data & Business Analytics',
    'Análise de TI & Automações de Fluxo',
    'Implantação / Parametrização de ERP (Protheus, Tasy, Senior)',
    'Inteligência Artificial Local (Gotham / Qwen)',
    'Consultoria de Processos & Business Agility',
    'Posição Executiva / Contratação Internacional',
  ];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedEmail(text);
    setTimeout(() => setCopiedEmail(null), 2000);
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setStep(2);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // Direct link to WhatsApp prefilled message
    const waUrl = formatWhatsAppMessage({
      name,
      serviceFocus,
      email: email || undefined,
      budget,
      notes: notes || undefined,
    });
    window.open(waUrl, '_blank');
  };

  return (
    <section id="contato" className="relative py-20 lg:py-28 bg-[#050508] border-b border-zinc-900 bg-dot-matrix">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col gap-2 mb-14">
          <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.3em] uppercase">
            <span className="w-1.5 h-1.5 bg-[#ff1e38]" />
            <span>05 // TRANSMIT INFORMATION</span>
          </div>
          <h2 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold uppercase text-white tracking-tight">
            {isPt ? 'INICIAR DIÁLOGO SEGURO' : 'TRANSMIT INFORMATION'}
          </h2>
          <p className="font-tactical text-lg sm:text-xl text-zinc-400 max-w-3xl">
            {isPt
              ? 'Entre em contato para posições estratégicas e consultoria sob medida.'
              : 'Direct communication line for strategic roles and tailored enterprise consulting.'}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: Direct Communication Channels */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <div className="p-6 sm:p-8 bg-[#0a0a10] border border-zinc-800 rounded-xs">
              <h3 className="font-tactical text-lg font-bold text-white uppercase tracking-wider mb-6 flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#ff1e38]" />
                <span>{isPt ? 'Canais de Comunicação Direta' : 'Direct Channels'}</span>
              </h3>

              <div className="space-y-5 font-tech text-xs">
                {/* Channel 1 */}
                <div className="p-3.5 bg-zinc-950/70 border border-zinc-800 rounded-xs flex items-center justify-between gap-3">
                  <div>
                    <div className="text-[10px] text-zinc-500 uppercase tracking-widest">
                      General / AI Systems
                    </div>
                    <div className="text-zinc-200 font-mono text-xs sm:text-sm">neuroforgezack@gmail.com</div>
                  </div>
                  <button
                    onClick={() => handleCopy('neuroforgezack@gmail.com')}
                    className="p-2 text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800 rounded-xs transition-colors cursor-pointer"
                    title="Copiar e-mail"
                  >
                    {copiedEmail === 'neuroforgezack@gmail.com' ? (
                      <Check className="w-3.5 h-3.5 text-green-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Channel 2 */}
                <div className="p-3.5 bg-zinc-950/70 border border-zinc-800 rounded-xs flex items-center justify-between gap-3">
                  <div>
                    <div className="text-[10px] text-zinc-500 uppercase tracking-widest">
                      Intelligence Studio / IT Operations
                    </div>
                    <div className="text-zinc-200 font-mono text-xs sm:text-sm">contato.zackstudio@gmail.com</div>
                  </div>
                  <button
                    onClick={() => handleCopy('contato.zackstudio@gmail.com')}
                    className="p-2 text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800 rounded-xs transition-colors cursor-pointer"
                    title="Copiar e-mail"
                  >
                    {copiedEmail === 'contato.zackstudio@gmail.com' ? (
                      <Check className="w-3.5 h-3.5 text-green-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Channel 3: WhatsApp */}
                <div className="p-3.5 bg-zinc-950/70 border border-red-500/30 rounded-xs flex items-center justify-between gap-3">
                  <div>
                    <div className="text-[10px] text-[#ff334b] uppercase tracking-widest">
                      WhatsApp Coordinate
                    </div>
                    <div className="text-white font-mono text-xs sm:text-sm font-bold">+55 21 99031-5582</div>
                  </div>
                  <a
                    href="https://wa.me/5521990315582?text=Ol%C3%A1%20Isaac%2C%20gostaria%20de%20iniciar%20um%20di%C3%A1logo%20executivo."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-white bg-[#ff1e38] hover:bg-[#ff334b] rounded-xs transition-colors"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Direct WhatsApp Big CTA */}
              <div className="mt-8">
                <a
                  href="https://wa.me/5521990315582?text=Ol%C3%A1%20Isaac%2C%20gostaria%20de%20iniciar%20um%20di%C3%A1logo%20executivo."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 w-full py-3.5 bg-[#ff1e38] hover:bg-[#ff334b] text-white font-tactical font-bold text-xs tracking-widest uppercase transition-all shadow-[0_0_20px_rgba(255,30,56,0.45)] rounded-xs"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>CONVERSAR NO WHATSAPP</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Security Guarantee Note */}
            <div className="p-4 bg-zinc-950/80 border border-zinc-800/80 text-xs font-tech text-zinc-400 rounded-xs flex items-center gap-3">
              <ShieldAlert className="w-5 h-5 text-[#ff1e38] shrink-0" />
              <span>
                {isPt
                  ? 'Tratamento de dados em conformidade com as diretrizes da LGPD e acordos de confidencialidade (NDA) corporativos.'
                  : 'Data handled under strict confidentiality, NDA compliance, and global privacy standards.'}
              </span>
            </div>
          </div>

          {/* Right Column: Interactive 2-Step Form */}
          <div className="lg:col-span-7 p-6 sm:p-8 bg-[#0a0a10] border border-red-500/30 red-glow-subtle rounded-xs">
            <div className="flex items-center justify-between pb-4 mb-6 border-b border-zinc-800">
              <div className="font-tech text-xs tracking-widest text-[#ff2e47] uppercase font-bold">
                {isPt ? `FORM STEP ${step} / 2` : `STEP ${step} OF 2`}
              </div>
              <div className="flex items-center gap-1.5">
                <span className={`w-6 h-1 ${step >= 1 ? 'bg-[#ff1e38]' : 'bg-zinc-800'}`} />
                <span className={`w-6 h-1 ${step >= 2 ? 'bg-[#ff1e38]' : 'bg-zinc-800'}`} />
              </div>
            </div>

            {submitted ? (
              <div className="py-12 flex flex-col items-center justify-center text-center">
                <div className="w-14 h-14 bg-green-950/60 border border-green-500/40 rounded-full flex items-center justify-center text-green-400 mb-4 shadow-[0_0_20px_rgba(34,197,94,0.4)]">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h4 className="font-display text-3xl font-bold uppercase text-white mb-2">
                  {isPt ? 'DIÁLOGO INICIADO COM SUCESSO' : 'INQUIRY TRANSMITTED'}
                </h4>
                <p className="font-body text-sm text-zinc-400 max-w-md mb-6">
                  {isPt
                    ? 'A janela de conversa do WhatsApp foi aberta com todos os parâmetros formatados. Responderemos com brevidade.'
                    : 'The encrypted WhatsApp dispatch channel was initialized with your project parameters.'}
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setStep(1);
                  }}
                  className="px-6 py-2.5 bg-zinc-900 border border-zinc-700 text-zinc-200 font-tactical text-xs tracking-widest uppercase rounded-xs"
                >
                  {isPt ? 'ENVIAR NOVA MENSAGEM' : 'SUBMIT ANOTHER'}
                </button>
              </div>
            ) : step === 1 ? (
              <form onSubmit={handleNextStep} className="space-y-6">
                <div>
                  <label className="block text-xs font-tech tracking-widest text-zinc-300 uppercase mb-2">
                    {isPt ? 'Seu Nome / Organização *' : 'Your Name / Organization *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Acme Corp. / Isaac Lamego"
                    className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 focus:border-[#ff1e38] text-white text-sm font-tech rounded-xs outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-tech tracking-widest text-zinc-300 uppercase mb-2">
                    {isPt ? 'Foco do Serviço *' : 'Service Domain Focus *'}
                  </label>
                  <select
                    value={serviceFocus}
                    onChange={(e) => setServiceFocus(e.target.value)}
                    className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 focus:border-[#ff1e38] text-white text-sm font-tech rounded-xs outline-none transition-colors"
                  >
                    {serviceOptions.map((opt) => (
                      <option key={opt} value={opt} className="bg-zinc-950 text-white">
                        {opt}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-tech tracking-widest text-zinc-300 uppercase mb-2">
                    {isPt ? 'Expectativa de Orçamento' : 'Budget Target'}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {['R$ 15k - R$ 30k', 'R$ 30k - R$ 60k', 'R$ 60k - R$ 75k+'].map((b) => (
                      <button
                        key={b}
                        type="button"
                        onClick={() => setBudget(b)}
                        className={`py-2 px-1 text-center font-tech text-xs rounded-xs border transition-colors cursor-pointer ${
                          budget === b
                            ? 'bg-red-950/60 border-[#ff1e38] text-white font-bold'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        {b}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    type="submit"
                    className="flex items-center gap-2 px-8 py-3 bg-[#ff1e38] hover:bg-[#ff334b] text-white font-tactical font-bold text-xs tracking-widest uppercase transition-all shadow-[0_0_20px_rgba(255,30,56,0.4)] rounded-xs cursor-pointer"
                  >
                    <span>{isPt ? 'AVANÇAR' : 'NEXT STEP'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-tech tracking-widest text-zinc-300 uppercase mb-2">
                      {isPt ? 'E-mail de Contato' : 'Contact Email'}
                    </label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu.email@empresa.com"
                      className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 focus:border-[#ff1e38] text-white text-sm font-tech rounded-xs outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-tech tracking-widest text-zinc-300 uppercase mb-2">
                      {isPt ? 'Telefone / WhatsApp' : 'Phone / WhatsApp'}
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+55 (21) 99999-9999"
                      className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 focus:border-[#ff1e38] text-white text-sm font-tech rounded-xs outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-tech tracking-widest text-zinc-300 uppercase mb-2">
                    {isPt ? 'Detalhes do Projeto / Demanda' : 'Project Notes / Scope Brief'}
                  </label>
                  <textarea
                    rows={3}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder={
                      isPt
                        ? 'Descreva brevemente o gargalo operacional, o sistema ERP envolvido ou os objetivos da consultoria...'
                        : 'Briefly describe operational challenges, ERP platforms, or consulting requirements...'
                    }
                    className="w-full px-4 py-3 bg-zinc-950 border border-zinc-800 focus:border-[#ff1e38] text-white text-sm font-tech rounded-xs outline-none transition-colors resize-none"
                  />
                </div>

                <div className="pt-4 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex items-center gap-2 px-5 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-tactical text-xs tracking-widest uppercase rounded-xs transition-colors cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>{isPt ? 'VOLTAR' : 'BACK'}</span>
                  </button>

                  <button
                    type="submit"
                    className="flex items-center gap-2 px-8 py-3 bg-[#ff1e38] hover:bg-[#ff334b] text-white font-tactical font-bold text-xs tracking-widest uppercase transition-all shadow-[0_0_25px_rgba(255,30,56,0.5)] rounded-xs cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isPt ? 'TRANSMITIR MENSAGEM' : 'TRANSMIT MESSAGE'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
