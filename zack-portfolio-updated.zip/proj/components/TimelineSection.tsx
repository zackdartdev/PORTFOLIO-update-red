'use client';

import React from 'react';
import { Briefcase, Calendar, Globe, CheckCircle2, TrendingUp, DollarSign } from 'lucide-react';

interface TimelineSectionProps {
  currentLang: 'pt' | 'en';
}

export default function TimelineSection({ currentLang }: TimelineSectionProps) {
  const isPt = currentLang === 'pt';

  const skyvisionDuties = [
    isPt
      ? 'Responsável pela infraestrutura de TI de uma empresa internacional de serviços digitais, atuando com autonomia junto à liderança executiva em decisões administrativas e operacionais.'
      : 'Managed the IT infrastructure of an international digital services firm, acting with executive autonomy in administrative and operational choices.',
    isPt
      ? 'Apoio técnico e operacional na entrega de serviços e projetos para mais de 30 empresas atendidas, incluindo apoio operacional em lançamentos de cursos de grande escala, landing pages, sites institucionais e automações de processos.'
      : 'Technical and operational delivery across 30+ enterprise clients, supporting high-scale course launches, institutional sites, and automated processes.',
    isPt
      ? 'Uso estratégico de inteligências artificiais para otimizar fluxos de desenvolvimento e engenharia de prompt aplicada a tarefas administrativas.'
      : 'Strategic integration of artificial intelligence models to optimize development pipelines and administrative prompt engineering.',
    isPt
      ? 'Centralização da gestão administrativa de projetos, mapeamento de fluxos organizacionais e documentação de processos no Notion para apoiar a eficiência das equipes.'
      : 'Centralized administrative project governance, organizational workflow mapping, and systemic documentation in Notion driving team velocity.',
    isPt
      ? 'Condução de rotinas administrativas, gestão de prazos e reuniões de negociação internacionais, com atendimento direto a clientes estrangeiros em regime 100% remoto (Suíça, Alemanha, França, EUA, Portugal e Brasil).'
      : 'Spearheaded administrative routines, deadline enforcement, and international negotiation meetings directly with global clients 100% remotely.',
    isPt
      ? 'Estruturação técnica de um projeto de ecossistema empresarial (aplicativo integrado de alta complexidade), incluindo a formatação e defesa de orçamento estratégico entre R$ 60k e R$ 75k.'
      : 'Technical structuring of an integrated enterprise ecosystem app, including commercial defense of strategic budgets between R$ 60k and R$ 75k.',
  ];

  return (
    <section id="experiencia" className="relative py-20 lg:py-28 bg-[#050508] border-b border-zinc-900 bg-tactical-grid">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col gap-2 mb-14">
          <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.3em] uppercase">
            <span className="w-1.5 h-1.5 bg-[#ff1e38]" />
            <span>03 // TIMELINE</span>
          </div>
          <h2 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold uppercase text-white tracking-tight">
            {isPt ? 'EXPERIÊNCIA PROFISSIONAL' : 'PROFESSIONAL EXPERIENCE'}
          </h2>
          <p className="font-tactical text-lg sm:text-xl text-zinc-400 max-w-3xl">
            {isPt
              ? 'Trajetória corporativa, liderança em operações internacionais e governança de tecnologia.'
              : 'Corporate track record, international remote governance, and technology operations.'}
          </p>
        </div>

        {/* Timeline Stream */}
        <div className="space-y-12">
          
          {/* Main Experience Card: SkyVision Creative Studio */}
          <div className="relative pl-6 sm:pl-10 border-l-2 border-[#ff1e38]">
            <div className="absolute -left-[9px] top-0 w-4 h-4 bg-[#ff1e38] rounded-full shadow-[0_0_12px_#ff1e38]" />

            <div className="p-6 sm:p-8 bg-[#0a0a10] border border-zinc-800 rounded-xs relative overflow-hidden">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2 text-xs font-tech text-[#ff334b] tracking-widest uppercase">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Junho de 2024 – Setembro de 2026</span>
                </div>
                <div className="flex items-center gap-2 px-2.5 py-1 bg-red-950/60 border border-red-500/40 text-[11px] font-tech text-red-300 rounded-xs w-fit">
                  <Globe className="w-3 h-3 text-[#ff1e38]" />
                  <span>100% REMOTE // INTERNATIONAL</span>
                </div>
              </div>

              <h3 className="font-display text-3xl sm:text-4xl font-bold text-white uppercase tracking-wide">
                SkyVision Creative Studio
              </h3>

              <div className="font-tactical text-base sm:text-lg font-semibold text-zinc-300 uppercase tracking-wide mb-2">
                Analista de TI, Processos e Suporte Administrativo (Contractor)
              </div>

              <div className="text-xs font-tech text-zinc-400 mb-6 flex flex-wrap gap-2">
                <span className="text-[#ff1e38]">SCOPE:</span>
                <span>Switzerland, France, USA, PT, BR, Germany</span>
              </div>

              {/* Duties Checklist */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-zinc-900">
                {skyvisionDuties.map((duty, idx) => (
                  <div key={idx} className="flex gap-3 text-zinc-300 font-body text-xs sm:text-sm leading-relaxed">
                    <CheckCircle2 className="w-4 h-4 text-[#ff1e38] shrink-0 mt-0.5" />
                    <span>{duty}</span>
                  </div>
                ))}
              </div>

              {/* Financial & Scale Banner */}
              <div className="mt-8 pt-5 border-t border-zinc-900 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-3 bg-zinc-950/60 border border-zinc-800 rounded-xs flex items-center gap-3">
                  <TrendingUp className="w-5 h-5 text-[#ff1e38]" />
                  <div>
                    <div className="text-[10px] font-tech text-zinc-500 uppercase">Volume Operacional</div>
                    <div className="font-tactical font-bold text-sm text-white">30+ EMPRESAS & LANÇAMENTOS ESCALAIS</div>
                  </div>
                </div>

                <div className="p-3 bg-zinc-950/60 border border-zinc-800 rounded-xs flex items-center gap-3">
                  <DollarSign className="w-5 h-5 text-[#ff1e38]" />
                  <div>
                    <div className="text-[10px] font-tech text-zinc-500 uppercase">Defesa de Orçamento</div>
                    <div className="font-tactical font-bold text-sm text-[#ff334b]">R$ 60.000 A R$ 75.000 POR PROJETO</div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Extension: Consultoria de TI e Processos */}
          <div className="relative pl-6 sm:pl-10 border-l-2 border-zinc-800">
            <div className="absolute -left-[9px] top-0 w-4 h-4 bg-zinc-800 rounded-full border-2 border-zinc-700" />

            <div className="p-6 sm:p-8 bg-[#08080d] border border-zinc-800/80 rounded-xs">
              <div className="text-xs font-tech text-zinc-400 tracking-widest uppercase mb-1">
                EXTENSÃO DE PROJETOS // STRATEGIC ADVISORY
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-white uppercase tracking-wide mb-1">
                Consultoria de TI e Processos
              </h3>
              <div className="font-tactical text-sm font-semibold text-[#ff334b] uppercase tracking-wide mb-4">
                TI, Contabilidade & Processos
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-zinc-300 font-body text-xs sm:text-sm leading-relaxed">
                <p>
                  {isPt
                    ? 'Aplicação de conhecimento em informática e banco de dados para analisar rotinas administrativas, traduzindo regras contábeis e de gestão administrativa em oportunidades de otimização de sistemas.'
                    : 'Applying computer science and database management to evaluate operational routines, translating accounting rules and executive management requirements into system-level optimizations.'}
                </p>
                <p>
                  {isPt
                    ? 'Estudo da lógica de funcionamento e integração de dados de ecossistemas de ERP (Protheus, Tasy, Sênior e 4medic), identificando gargalos operacionais antes da implementação técnica.'
                    : 'In-depth architectural analysis and data integration across ERP ecosystems (Protheus, Tasy, Senior, 4medic), preemptively eliminating operational friction prior to production deployment.'}
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
