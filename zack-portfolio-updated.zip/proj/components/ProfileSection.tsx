'use client';

import React from 'react';
import { Shield, BookOpen, Globe2, Scale, Users2, ArrowRight, CheckCircle2 } from 'lucide-react';

interface ProfileSectionProps {
  currentLang: 'pt' | 'en';
}

export default function ProfileSection({ currentLang }: ProfileSectionProps) {
  const isPt = currentLang === 'pt';

  const competencies = [
    {
      title: isPt ? 'Inglês Avançado (Escrito & Falado)' : 'Fluent English (Spoken & Written)',
      desc: isPt
        ? 'Negociações diretas, alinhamentos executivos e condução de rotinas com clientes e equipes nos EUA, Suíça, Alemanha e França.'
        : 'Direct negotiations, executive alignments, and routines with stakeholders across USA, Switzerland, Germany, and France.',
      icon: Globe2,
    },
    {
      title: isPt ? 'Sólida Base Jurídica Aplicada' : 'Solid Applied Legal Foundation',
      desc: isPt
        ? 'Conhecimento aplicado em Direito Administrativo, Constitucional, Civil, Penal e Processual Penal para auditoria de contratos, riscos e conformidade legal.'
        : 'Applied knowledge in Administrative, Constitutional, Civil, Penal, and Procedural Law for contract audit, compliance, and corporate risk mitigation.',
      icon: Scale,
    },
    {
      title: isPt ? 'Liderança & Decisão sob Pressão' : 'Leadership & High-Stakes Judgment',
      desc: isPt
        ? 'Instinto de liderança, rapidez de retenção conceitual e tomada de decisão fundamentada em métricas financeiras e operacionais.'
        : 'Leadership instinct, fast intellectual absorption, and sound decision-making under operational and economic pressure.',
      icon: Users2,
    },
    {
      title: isPt ? 'Rotinas de Administração & Contabilidade' : 'Administration & Accounting Routines',
      desc: isPt
        ? 'Domínio de administração geral, pública, fluxos contábeis, controladoria e parametrização fiscal corporativa.'
        : 'Mastery of public and corporate administration, accounting workflows, financial controllership, and tax parameters.',
      icon: BookOpen,
    },
  ];

  return (
    <section id="sobre" className="relative py-20 lg:py-28 bg-[#07070b] border-b border-zinc-900">
      {/* Background Accent Gradients */}
      <div className="absolute top-10 left-1/3 w-96 h-96 bg-red-600/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col gap-2 mb-12">
          <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.3em] uppercase">
            <span className="w-1.5 h-1.5 bg-[#ff1e38]" />
            <span>01 // PROFILE</span>
          </div>
          <h2 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold uppercase text-white tracking-tight">
            {isPt ? 'SOBRE MIM' : 'ABOUT ME'}
          </h2>
          <p className="font-tactical text-lg sm:text-xl text-zinc-400 max-w-3xl">
            {isPt
              ? 'Operando na interseção entre tecnologia e gestão administrativa.'
              : 'Operating at the intersection of technology and administrative management.'}
          </p>
        </div>

        {/* 2-Column Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: Narrative Biography */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            <div className="p-6 sm:p-8 bg-[#0b0c12] border border-zinc-800 rounded-xs relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-[#ff1e38]" />
              
              <div className="flex items-center gap-2 mb-4 text-xs font-tech text-zinc-400 uppercase tracking-widest">
                <span className="text-[#ff1e38]">ISAAC LAMEGO</span>
                <span>//</span>
                <span>EXECUTIVE BIO</span>
              </div>

              <div className="font-body text-zinc-300 text-base sm:text-lg leading-relaxed flex flex-col gap-4">
                <p>
                  {isPt
                    ? 'Meu nome é Isaac Lamego, sou um profissional multidisciplinar com atuação na interseção entre tecnologia e gestão administrativa. Com sólida base analítica moldada em sistemas, direciono minha carreira para a gestão de processos, o suporte administrativo e a inteligência de negócios.'
                    : 'My name is Isaac Lamego, a multidisciplinary professional working at the intersection of technology and administrative management. With a solid analytical background grounded in software systems, I direct my career toward process governance, administrative support, and business intelligence.'}
                </p>

                <p>
                  {isPt
                    ? 'Tenho instinto de liderança, boa capacidade de julgamento e tomada de decisão sob pressão, aliados à alta velocidade de retenção e aplicação prática de conteúdos complexos. Possuo domínio de rotinas de administração geral, pública e contabilidade, além de base jurídica sólida, com conhecimento aplicado em Direito Administrativo, Constitucional, Civil, Penal e Processual Penal.'
                    : 'I have a leadership instinct, sharp judgment, and decisive decision-making under pressure, coupled with rapid retention and practical execution of complex frameworks. I master general and public administration routines, accounting, and hold a solid legal foundation in Administrative, Constitutional, Civil, Criminal, and Procedural Law.'}
                </p>

                <p>
                  {isPt
                    ? 'Com comunicação assertiva, boa oratória e inglês avançado (escrito e falado), tenho experiência em gerenciar metas, conduzir reuniões executivas e apoiar operações remotas em nível internacional.'
                    : 'With assertive communication, strong public speaking, and fluent English (written and spoken), I have extensive experience driving business goals, leading executive discussions, and steering high-performance remote operations internationally.'}
                </p>
              </div>

              {/* Bottom Schedule Callout inside bio */}
              <div className="mt-8 pt-6 border-t border-zinc-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="font-display text-xl sm:text-2xl font-bold uppercase text-white">
                    {isPt
                      ? 'Deseja agendar uma reunião ou entrevista executiva?'
                      : 'Looking to schedule an executive interview?'}
                  </div>
                  <div className="font-tech text-xs text-zinc-400">
                    {isPt ? 'Disponibilidade imediata para alinhamento estratégico.' : 'Immediate availability for strategic alignment.'}
                  </div>
                </div>

                <a
                  href="#contato"
                  className="inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-[#ff1e38] hover:bg-[#ff334b] text-white font-tactical font-bold text-xs tracking-widest uppercase transition-all shadow-[0_0_15px_rgba(255,30,56,0.4)] rounded-xs whitespace-nowrap"
                >
                  <span>{isPt ? 'AGENDAR' : 'SCHEDULE'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Key Pillars & Legal/Management Competencies */}
          <div className="lg:col-span-5 grid grid-cols-1 gap-4">
            {competencies.map((c, idx) => {
              const Icon = c.icon;
              return (
                <div
                  key={idx}
                  className="p-5 bg-[#0b0c12]/80 border border-zinc-800 hover:border-red-500/40 transition-colors rounded-xs flex gap-4"
                >
                  <div className="w-10 h-10 shrink-0 bg-red-950/40 border border-red-500/30 flex items-center justify-center rounded-xs text-[#ff1e38]">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-tactical text-base sm:text-lg font-bold text-white uppercase tracking-wide mb-1">
                      {c.title}
                    </h3>
                    <p className="font-body text-xs sm:text-sm text-zinc-400 leading-relaxed">
                      {c.desc}
                    </p>
                  </div>
                </div>
              );
            })}

            {/* Quick Summary Pill */}
            <div className="p-4 bg-zinc-900/40 border border-zinc-800 text-xs font-tech text-zinc-400 rounded-xs flex items-center justify-between">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#ff1e38]" />
                <span>GOVERNANÇA & COMPLIANCE VERIFICADOS</span>
              </span>
              <span className="text-zinc-500">ISO / LGPD ALIGNED</span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
