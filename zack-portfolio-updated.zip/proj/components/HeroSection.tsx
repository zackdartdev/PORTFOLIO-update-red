'use client';

import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, ShieldCheck, ChevronRight, Activity, Calendar, ExternalLink, Terminal } from 'lucide-react';
import HeroCharacterVideo from './HeroCharacterVideo';

interface HeroSectionProps {
  currentLang: 'pt' | 'en';
}

export default function HeroSection({ currentLang }: HeroSectionProps) {
  const isPt = currentLang === 'pt';

  return (
    <section className="relative pt-28 pb-16 lg:pt-36 lg:pb-24 overflow-hidden border-b border-zinc-900 bg-tactical-grid">
      {/* Background Radial Glow */}
      <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] bg-red-600/10 rounded-full blur-[130px] pointer-events-none -z-10" />
      <div className="absolute bottom-0 left-10 w-[400px] h-[400px] bg-[#ff1e38]/5 rounded-full blur-[110px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main 2-Column Hero Layout matching Reference Image 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Headlines, Copy, CTAs, and Stats Bar */}
          <div className="lg:col-span-7 flex flex-col justify-center z-10">
            {/* Red Category Sub-kicker matching Reference 1 ("NEXT-GEN GAME & WEB EXPERIENCES") */}
            <div className="flex items-center gap-2.5 mb-4">
              <span className="w-2 h-2 bg-[#ff1e38] shadow-[0_0_8px_#ff1e38]" />
              <span className="font-tech text-xs sm:text-sm font-bold tracking-[0.2em] text-[#ff2e47] uppercase">
                {isPt
                  ? 'TI ORIENTADA A GESTÃO EMPRESARIAL, BI E ANÁLISE DE RISCO'
                  : 'IT FOR ENTERPRISE MANAGEMENT, BI & RISK ANALYSIS'}
              </span>
            </div>

            <div className="inline-block text-xs font-tech font-semibold tracking-widest text-zinc-400 mb-2 uppercase">
              {isPt ? 'Analista de TI & Operações Estratégicas' : 'IT Analyst & Strategic Operations'}
            </div>

            {/* Giant Condensed Headline matching Reference 1 ("WE DESIGN EXPERIENCES THAT WIN.") */}
            <h1 className="font-display text-7xl sm:text-8xl md:text-[7.5rem] lg:text-[8rem] leading-[0.82] font-bold text-white tracking-tight uppercase mb-6">
              ZACK<br />
              <span className="text-[#ff1e38] drop-shadow-[0_0_35px_rgba(255,30,56,0.5)]">
                ENTERPRISE
              </span><br />
              STUDIOS.
            </h1>

            {/* Body Copy provided by user */}
            <p className="font-body text-zinc-300 text-base sm:text-lg leading-relaxed max-w-2xl mb-8 border-l-2 border-[#ff1e38]/60 pl-4 bg-zinc-950/30 py-1">
              {isPt
                ? 'Articulando inteligência de dados, engenharia de software, sólidos fundamentos jurídicos e gestão administrativa de processos para escalar operações corporativas.'
                : 'Articulating data intelligence, software engineering, solid legal foundations, and administrative process management to scale corporate operations.'}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4 mb-10">
              <a
                href="#contato"
                className="group flex items-center gap-3 px-7 py-3.5 bg-[#ff1e38] hover:bg-[#ff334b] text-white font-tactical font-bold text-sm tracking-widest uppercase transition-all shadow-[0_0_25px_rgba(255,30,56,0.45)] hover:shadow-[0_0_35px_rgba(255,30,56,0.7)] rounded-xs cursor-pointer"
              >
                <span>{isPt ? 'ENTRAR EM CONTATO AGORA' : 'GET IN TOUCH NOW'}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </a>

              <a
                href="#sobre"
                className="flex items-center gap-2 px-6 py-3.5 bg-zinc-900/80 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-zinc-700/80 hover:border-zinc-500 font-tactical font-bold text-sm tracking-widest uppercase transition-colors rounded-xs"
              >
                <span>{isPt ? 'CONHECER PERFIL' : 'VIEW PROFILE'}</span>
                <ChevronRight className="w-4 h-4 text-zinc-400" />
              </a>
            </div>

            {/* Stats Row matching Reference 1 (120+ PROJECTS / 8 YEARS / 98% CLIENT SATISFACTION) */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 pt-6 border-t border-zinc-800/80">
              <div>
                <div className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-[#ff1e38] tracking-tight leading-none">
                  100%
                </div>
                <div className="font-tech text-[9px] sm:text-[11px] tracking-wider text-zinc-400 uppercase mt-1 leading-tight">
                  {isPt ? 'Operação Remota Segura' : 'Secure Remote Ops'}
                </div>
              </div>

              <div>
                <div className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-[#ff1e38] tracking-tight leading-none">
                  30+
                </div>
                <div className="font-tech text-[9px] sm:text-[11px] tracking-wider text-zinc-400 uppercase mt-1 leading-tight">
                  {isPt ? 'Empresas Atendidas' : 'Clients Served'}
                </div>
              </div>

              <div>
                <div className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-[#ff1e38] tracking-tight leading-none">
                  R$ 75k
                </div>
                <div className="font-tech text-[9px] sm:text-[11px] tracking-wider text-zinc-400 uppercase mt-1 leading-tight">
                  {isPt ? 'Orçamento Único Projetos' : 'Top Project Budget'}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: 3D Scene + Callout Block + Trusted Logos */}
          <div className="lg:col-span-5 relative flex flex-col items-center">
            {/* Operator character video (eyes follow the cursor) — replaces the former 3D mask */}
            <HeroCharacterVideo />

            {/* Trusted By International Scope & Stacks */}
            <div className="w-full mt-4 flex flex-col gap-2">
              <div className="flex items-center justify-between text-[11px] font-tech tracking-widest text-zinc-400 uppercase">
                <span>{isPt ? 'EXPERIÊNCIA REMOTA INTERNACIONAL' : 'INTERNATIONAL REMOTE SCOPE'}</span>
                <span className="text-[#ff1e38]">6 COUNTRIES</span>
              </div>
              <div className="flex flex-wrap gap-2 text-xs font-tech">
                {['🇨🇭 Switzerland', '🇫🇷 France', '🇺🇸 USA', '🇵🇹 Portugal', '🇧🇷 Brasil', '🇩🇪 Germany'].map((country) => (
                  <span
                    key={country}
                    className="px-2.5 py-1 bg-zinc-900/90 border border-zinc-800 text-zinc-300 rounded-xs"
                  >
                    {country}
                  </span>
                ))}
              </div>
            </div>

            {/* Bottom-right Callout Box matching Reference 1 ("READY TO CREATE SOMETHING LEGENDARY?") */}
            <div className="w-full mt-6 p-5 sm:p-6 bg-[#0a0a10]/90 border border-red-500/30 red-glow-subtle rounded-xs relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-red-600/10 rounded-bl-full pointer-events-none" />
              
              <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-widest uppercase mb-1">
                <Calendar className="w-3.5 h-3.5" />
                <span>{isPt ? 'DIÁLOGO EXECUTIVO' : 'EXECUTIVE ENGAGEMENT'}</span>
              </div>

              <h3 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-wide uppercase leading-tight mb-2">
                {isPt
                  ? 'DESEJA AGENDAR UMA REUNIÃO OU ENTREVISTA EXECUTIVA?'
                  : 'READY TO SCHEDULE AN EXECUTIVE INTERVIEW?'}
              </h3>

              <p className="font-body text-xs sm:text-sm text-zinc-400 mb-4">
                {isPt
                  ? 'Apoio técnico e estratégico para governança de TI, BI, automações com IA e modelagem de processos corporativos.'
                  : 'Technical and strategic support for IT governance, BI, AI workflows, and corporate process modeling.'}
              </p>

              <a
                href="#contato"
                className="inline-flex items-center justify-center gap-2 w-full py-2.5 bg-[#ff1e38] hover:bg-[#ff334b] text-white font-tactical font-bold text-xs tracking-widest uppercase transition-all shadow-[0_0_20px_rgba(255,30,56,0.35)] rounded-xs"
              >
                <span>{isPt ? 'AGENDAR REUNIÃO AGORA' : 'SCHEDULE CALL NOW'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Row: Featured Projects / Key Highlights (Matching Reference 1 FEATURED PROJECT section) */}
        <div className="mt-14 pt-10 border-t border-zinc-900">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.25em] uppercase">
              <span className="w-1.5 h-1.5 bg-[#ff1e38]" />
              <span>{isPt ? 'DESTAQUES OPERACIONAIS // FEATURED ARCHITECTURES' : 'FEATURED ARCHITECTURES'}</span>
            </div>
            <a
              href="#especialidades"
              className="text-xs font-tech text-zinc-400 hover:text-white flex items-center gap-1 uppercase tracking-wider"
            >
              <span>{isPt ? 'VER TODAS' : 'VIEW ALL'}</span>
              <ChevronRight className="w-3 h-3 text-[#ff1e38]" />
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Card 1: Gotham AI (The Finals style) */}
            <a
              href="#ia"
              className="group relative p-5 bg-[#0b0c12] hover:bg-[#10111a] border border-zinc-800/80 hover:border-red-500/50 transition-all duration-300 rounded-xs overflow-hidden flex flex-col justify-between"
            >
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-red-600/10 to-transparent pointer-events-none" />
              <div>
                <div className="flex justify-between items-center text-[10px] font-tech text-zinc-500 tracking-widest uppercase mb-3">
                  <span className="text-[#ff334b]">FEATURED // AI LOCAL</span>
                  <span>STATUS: ACTIVE</span>
                </div>
                <h4 className="font-display text-2xl font-bold text-white tracking-wide uppercase group-hover:text-[#ff1e38] transition-colors mb-2">
                  GOTHAM — DECISION AI
                </h4>
                <p className="font-body text-xs text-zinc-400 leading-relaxed mb-4">
                  {isPt
                    ? 'Assistente local de apoio à decisão com Qwen, Ollama e Node.js para tratamento e síntese de CSV/planilhas sem envio a serviços externos.'
                    : 'Local decision-support AI agent with Qwen & Ollama processing CSV sheets locally without cloud exposure.'}
                </p>
              </div>

              <div className="pt-3 border-t border-zinc-900 flex items-center justify-between text-[11px] font-tech text-zinc-400">
                <span>Qwen • Ollama • Node.js</span>
                <span className="text-[#ff1e38] group-hover:translate-x-1 transition-transform flex items-center">
                  TESTAR &rarr;
                </span>
              </div>
            </a>

            {/* Card 2: SkyVision (Arc Raiders style) */}
            <a
              href="#experiencia"
              className="group relative p-5 bg-[#0b0c12] hover:bg-[#10111a] border border-zinc-800/80 hover:border-red-500/50 transition-all duration-300 rounded-xs overflow-hidden flex flex-col justify-between"
            >
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-red-600/10 to-transparent pointer-events-none" />
              <div>
                <div className="flex justify-between items-center text-[10px] font-tech text-zinc-500 tracking-widest uppercase mb-3">
                  <span className="text-[#ff334b]">OPERATIONS // REMOTE</span>
                  <span>30+ CLIENTES</span>
                </div>
                <h4 className="font-display text-2xl font-bold text-white tracking-wide uppercase group-hover:text-[#ff1e38] transition-colors mb-2">
                  SKYVISION CREATIVE STUDIO
                </h4>
                <p className="font-body text-xs text-zinc-400 leading-relaxed mb-4">
                  {isPt
                    ? 'Infraestrutura de TI e governança remota internacional. Negociações em inglês, orçamentos até R$75k e hub de processos no Notion.'
                    : 'IT infrastructure and international remote governance. Fluent English negotiations, R$75k budgets, and Notion process modeling.'}
                </p>
              </div>

              <div className="pt-3 border-t border-zinc-900 flex items-center justify-between text-[11px] font-tech text-zinc-400">
                <span>Contractor 100% Remoto</span>
                <span className="text-[#ff1e38] group-hover:translate-x-1 transition-transform flex items-center">
                  DETALHES &rarr;
                </span>
              </div>
            </a>

            {/* Card 3: ERP Model (Battlefield Redsec style) */}
            <a
              href="#especialidades"
              className="group relative p-5 bg-[#0b0c12] hover:bg-[#10111a] border border-zinc-800/80 hover:border-red-500/50 transition-all duration-300 rounded-xs overflow-hidden flex flex-col justify-between"
            >
              <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-red-600/10 to-transparent pointer-events-none" />
              <div>
                <div className="flex justify-between items-center text-[10px] font-tech text-zinc-500 tracking-widest uppercase mb-3">
                  <span className="text-[#ff334b]">ENTERPRISE // SYSTEMS</span>
                  <span>MULTI-ERP</span>
                </div>
                <h4 className="font-display text-2xl font-bold text-white tracking-wide uppercase group-hover:text-[#ff1e38] transition-colors mb-2">
                  ERP COMPREHENSION MODEL
                </h4>
                <p className="font-body text-xs text-zinc-400 leading-relaxed mb-4">
                  {isPt
                    ? 'Aptidão e modelagem lógica de fluxos fiscais, contábeis e APIs de integração em Protheus (TOTVS), Tasy, Senior e 4medic.'
                    : 'System logic analysis, fiscal flow mapping, and REST/SOAP API integration across Protheus, Tasy, Senior, and 4medic.'}
                </p>
              </div>

              <div className="pt-3 border-t border-zinc-900 flex items-center justify-between text-[11px] font-tech text-zinc-400">
                <span>REST / SOAP • Fiscal • Suprimentos</span>
                <span className="text-[#ff1e38] group-hover:translate-x-1 transition-transform flex items-center">
                  SIMULAR &rarr;
                </span>
              </div>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
}
