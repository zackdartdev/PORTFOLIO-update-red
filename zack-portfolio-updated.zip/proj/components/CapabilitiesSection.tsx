'use client';

import React, { useState } from 'react';
import {
  Cpu,
  Bot,
  Workflow,
  Database,
  FileCheck2,
  DollarSign,
  Check,
  Server,
  Layers,
  ArrowRight,
  GitBranch,
} from 'lucide-react';
import { ERP_SYSTEMS, getErpSystem } from '@/lib/portfolio';

interface CapabilitiesSectionProps {
  currentLang: 'pt' | 'en';
}

export default function CapabilitiesSection({ currentLang }: CapabilitiesSectionProps) {
  const isPt = currentLang === 'pt';
  const [selectedErp, setSelectedErp] = useState<string>('protheus');

  const capabilities = [
    {
      title: isPt ? 'Análise de TI e Automações' : 'IT Analysis & Automation',
      desc: isPt
        ? 'Suporte à engenharia e arquitetura de soluções, criação de infraestruturas digitais, sites, landing pages e automações de fluxos de trabalho para reduzir gargalos operacionais.'
        : 'Support for engineering and solution architecture, digital infrastructure, web platforms, and automated workflows to eliminate operational bottlenecks.',
      icon: Cpu,
      tag: 'SYS // ARCHITECTURE',
    },
    {
      title: isPt ? 'Ferramentas de IA e Tecnologias Modernas' : 'Modern AI Tools & Frameworks',
      desc: isPt
        ? 'Uso combinado de LLMs de mercado (com foco em Claude e seus modelos) e plataformas como Bolt.new, Lovable e Midjourney, para acelerar o ciclo de desenvolvimento e a criação de produtos digitais.'
        : 'Combined deployment of market LLMs (focused on Claude ecosystem) and platforms like Bolt.new, Lovable, and Midjourney to accelerate digital product cycles.',
      icon: Bot,
      tag: 'AI // ACCELERATION',
    },
    {
      title: isPt ? 'Gestão de Processos e Ferramentas' : 'Process Governance & Tooling',
      desc: isPt
        ? 'Organização de fluxos de trabalho, documentação e modelagem de processos utilizando o Notion como central de inteligência operacional e apoio à agilidade de equipes (Business Agility).'
        : 'Workflow organization, systematic documentation, and process modeling using Notion as an operational intelligence hub driving Business Agility.',
      icon: Workflow,
      tag: 'AGILITY // NOTION',
    },
    {
      title: isPt ? 'Conhecimento Técnico em ERPs' : 'Technical ERP Knowledge',
      desc: isPt
        ? 'Entendimento da estrutura, parametrização, fluxos de dados e lógica interna de plataformas como Protheus, Tasy, ERP Sênior e 4medic.'
        : 'In-depth comprehension of architecture, parameter setup, data pipelines, and core business rules across Protheus, Tasy, Senior ERP, and 4medic.',
      icon: Database,
      tag: 'ERP // DATA PIPELINES',
    },
    {
      title: isPt ? 'Gestão Administrativa, Auditoria e Riscos' : 'Admin Management, Audit & Risk',
      desc: isPt
        ? 'Interpretação de normas legais, aplicação de controles internos, apoio à gestão de contratos e atenção à segurança da informação em ambientes corporativos.'
        : 'Legal compliance analysis, internal control execution, corporate contract lifecycle audit, and proactive information security governance.',
      icon: FileCheck2,
      tag: 'RISK // GOVERNANCE',
    },
    {
      title: isPt ? 'Gestão Orçamentária e Negociação' : 'Budget Management & Negotiation',
      desc: isPt
        ? 'Apoio na precificação, estruturação técnica e defesa de propostas comerciais junto a tomadores de decisão nacionais e estrangeiros.'
        : 'Strategic pricing models, technical deal architecture, and commercial defense before domestic and global executive stakeholders.',
      icon: DollarSign,
      tag: 'FINANCE // DEFENSE',
    },
  ];

  const currentErpData = getErpSystem(selectedErp);

  return (
    <section id="especialidades" className="relative py-20 lg:py-28 bg-[#050508] border-b border-zinc-900 bg-dot-matrix">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col gap-2 mb-14">
          <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.3em] uppercase">
            <span className="w-1.5 h-1.5 bg-[#ff1e38]" />
            <span>02 // CAPABILITIES</span>
          </div>
          <h2 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold uppercase text-white tracking-tight">
            {isPt ? 'ÁREAS DE ATUAÇÃO' : 'CORE CAPABILITIES'}
          </h2>
          <p className="font-tactical text-lg sm:text-xl text-zinc-400 max-w-3xl">
            {isPt
              ? 'Competências e tecnologia aplicadas a negócios.'
              : 'Enterprise competencies and high-yield technology applied to business growth.'}
          </p>
        </div>

        {/* 6 Capabilities Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {capabilities.map((c, index) => {
            const Icon = c.icon;
            return (
              <div
                key={index}
                className="group p-6 bg-[#09090f]/90 hover:bg-[#0e0f17] border border-zinc-800/80 hover:border-red-500/50 transition-all duration-300 rounded-xs flex flex-col justify-between relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-red-600/10 to-transparent pointer-events-none" />
                
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <div className="w-10 h-10 bg-red-950/40 border border-red-500/30 flex items-center justify-center text-[#ff1e38] rounded-xs group-hover:scale-105 transition-transform">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="font-tech text-[10px] tracking-widest text-zinc-500 uppercase">
                      {c.tag}
                    </span>
                  </div>

                  <h3 className="font-tactical text-xl font-bold text-white uppercase tracking-wide mb-3 group-hover:text-[#ff1e38] transition-colors">
                    {c.title}
                  </h3>

                  <p className="font-body text-xs sm:text-sm text-zinc-400 leading-relaxed">
                    {c.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-zinc-900 flex items-center justify-between text-[11px] font-tech text-zinc-500">
                  <span>METRIC: OPERATIONAL GAIN</span>
                  <span className="text-[#ff1e38] group-hover:translate-x-1 transition-transform">
                    &bull;&bull;&bull;
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Interactive ERP COMPREHENSION MODEL (Highlighted in User prompt) */}
        <div className="p-6 sm:p-10 bg-[#090a10] border border-red-500/40 red-glow-subtle rounded-xs relative overflow-hidden">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-8 pb-6 border-b border-zinc-800">
            <div>
              <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.25em] uppercase mb-1">
                <Database className="w-3.5 h-3.5" />
                <span>ERP COMPREHENSION MODEL</span>
              </div>
              <h3 className="font-display text-3xl sm:text-4xl font-bold text-white uppercase tracking-wide">
                {isPt ? 'Lógica e Estrutura de ERPs' : 'ERP Logic & Enterprise Architecture'}
              </h3>
              <p className="font-body text-xs sm:text-sm text-zinc-400 mt-1 max-w-2xl">
                {isPt
                  ? 'Selecione os módulos abaixo para visualizar a minha aptidão e conhecimento analítico de parametrização e modelagem operacional em sistemas de mercado:'
                  : 'Select an ERP suite below to inspect structural comprehension, data workflows, and parametric API integration:'}
              </p>
            </div>

            {/* ERP Selector Tabs */}
            <div className="flex flex-wrap gap-2">
              {Object.keys(ERP_SYSTEMS).map((erpKey) => {
                const item = ERP_SYSTEMS[erpKey];
                const active = selectedErp === erpKey;
                return (
                  <button
                    key={erpKey}
                    onClick={() => setSelectedErp(erpKey)}
                    className={`px-4 py-2 font-tactical font-bold text-xs tracking-widest uppercase transition-all rounded-xs cursor-pointer ${
                      active
                        ? 'bg-[#ff1e38] text-white shadow-[0_0_15px_rgba(255,30,56,0.5)]'
                        : 'bg-zinc-900/80 hover:bg-zinc-800 text-zinc-400 border border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {item.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active ERP Details Display */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left: System Logic & Architecture */}
            <div className="lg:col-span-7 flex flex-col gap-5">
              <div className="p-5 bg-zinc-950/70 border border-zinc-800/80 rounded-xs">
                <div className="flex items-center justify-between text-xs font-tech text-zinc-400 mb-2">
                  <span className="text-[#ff334b] font-bold">{currentErpData.sysLogic}</span>
                  <span className="text-zinc-500">{currentErpData.vendor}</span>
                </div>
                <h4 className="font-tactical text-lg sm:text-xl font-bold text-white uppercase tracking-wide mb-2">
                  {isPt ? 'Arquitetura e Parametrização' : 'Architecture & Parameterization'}
                </h4>
                <p className="font-body text-sm text-zinc-300 leading-relaxed">
                  {currentErpData.architecture}
                </p>
              </div>

              {/* Status Badges */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-zinc-950/50 border border-zinc-800 rounded-xs">
                  <div className="text-[10px] font-tech text-zinc-500 uppercase tracking-widest mb-1">
                    Integration API Status
                  </div>
                  <div className="font-tactical text-base font-bold text-green-400 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_#22c55e]" />
                    {currentErpData.apiStatus}
                  </div>
                </div>

                <div className="p-4 bg-zinc-950/50 border border-zinc-800 rounded-xs">
                  <div className="text-[10px] font-tech text-zinc-500 uppercase tracking-widest mb-1">
                    Process Mapping
                  </div>
                  <div className="font-tactical text-base font-bold text-zinc-200 flex items-center gap-2">
                    <GitBranch className="w-4 h-4 text-[#ff1e38]" />
                    {currentErpData.processMapping}
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Mapped Modules Checklist */}
            <div className="lg:col-span-5 p-5 bg-zinc-950/70 border border-zinc-800/80 rounded-xs">
              <div className="text-xs font-tech text-zinc-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                <Layers className="w-3.5 h-3.5 text-[#ff1e38]" />
                <span>{isPt ? 'MÓDULOS DE ATUAÇÃO // CHECKLIST' : 'PARAMETRIC MODULES'}</span>
              </div>
              <div className="flex flex-col gap-2.5">
                {currentErpData.modules.map((m, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-3 p-2.5 bg-zinc-900/60 border border-zinc-800/70 rounded-xs text-xs font-tech text-zinc-200"
                  >
                    <div className="w-4 h-4 bg-red-950/60 border border-red-500/40 flex items-center justify-center text-[#ff1e38] shrink-0">
                      <Check className="w-3 h-3" />
                    </div>
                    <span>{m}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
