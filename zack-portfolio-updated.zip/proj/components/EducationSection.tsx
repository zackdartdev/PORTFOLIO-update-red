'use client';

import React from 'react';
import { GraduationCap, Award, BookOpen, Layers, CheckCircle, Target } from 'lucide-react';

interface EducationSectionProps {
  currentLang: 'pt' | 'en';
}

export default function EducationSection({ currentLang }: EducationSectionProps) {
  const isPt = currentLang === 'pt';

  const areasOfInterest = [
    {
      title: isPt ? 'Auditoria de Sistemas, Riscos e Gestão Administrativa' : 'Systems Audit, Risk Governance & Corporate Compliance',
      code: 'AREA_01',
    },
    {
      title: isPt ? 'Gestão de Operações de TI e Transformação Digital' : 'IT Operations Management & Digital Transformation',
      code: 'AREA_02',
    },
    {
      title: isPt ? 'Análise de Performance Corporativa e Planejamento Estratégico' : 'Corporate Performance Analytics & Strategic Planning',
      code: 'AREA_03',
    },
    {
      title: isPt ? 'Coordenação de Projetos e Apoio à Gestão de Equipes Híbridas' : 'Project Orchestration & Hybrid Team Operations',
      code: 'AREA_04',
    },
  ];

  return (
    <section id="formacao" className="relative py-20 lg:py-28 bg-[#07070b] border-b border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col gap-2 mb-14">
          <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.3em] uppercase">
            <span className="w-1.5 h-1.5 bg-[#ff1e38]" />
            <span>04 // EDUCATION</span>
          </div>
          <h2 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold uppercase text-white tracking-tight">
            {isPt ? 'FORMAÇÃO ACADÊMICA' : 'ACADEMIC BACKGROUND'}
          </h2>
          <p className="font-tactical text-lg sm:text-xl text-zinc-400 max-w-3xl">
            {isPt
              ? 'Fundamentação científica e estratégica.'
              : 'Scientific rigor and strategic management foundation.'}
          </p>
        </div>

        {/* 2 Degree Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          
          {/* Degree 1: ADS IBMR */}
          <div className="p-6 sm:p-8 bg-[#0b0c12] border border-zinc-800 rounded-xs flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-red-600/10 to-transparent pointer-events-none" />

            <div>
              <div className="flex items-center justify-between text-xs font-tech text-[#ff334b] tracking-widest uppercase mb-2">
                <span>GRADUAÇÃO TECNOLÓGICA</span>
                <span className="text-zinc-500">IBMR</span>
              </div>

              <h3 className="font-display text-2xl sm:text-3xl font-bold text-white uppercase tracking-wide mb-3">
                Análise e Desenvolvimento de Sistemas (ADS)
              </h3>

              <p className="font-body text-xs sm:text-sm text-zinc-300 leading-relaxed mb-6">
                {isPt
                  ? 'Formação voltada ao desenvolvimento de software: lógica de programação, análise e modelagem de sistemas, banco de dados e desenvolvimento web. Na prática, tenho proficiência em Node.js, Next.js, React, Git, GitHub e testes automatizados, usados para construir, versionar e validar aplicações com qualidade.'
                  : 'Software engineering degree: algorithmic logic, systems modeling, relational databases, and modern web architectures. Practical proficiency in Node.js, Next.js, React, Git, GitHub, and automated testing.'}
              </p>

              {/* Stack & Práticas */}
              <div className="mb-6">
                <div className="text-[11px] font-tech text-zinc-400 uppercase tracking-widest mb-2">
                  Stack e práticas:
                </div>
                <div className="flex flex-wrap gap-2">
                  {['Node.js', 'Next.js', 'React', 'Git', 'GitHub', 'Testes automatizados'].map((t) => (
                    <span
                      key={t}
                      className="px-2.5 py-1 text-xs font-tech bg-zinc-900 border border-zinc-800 text-zinc-200 rounded-xs"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Curricular Unit Complement */}
              <div className="p-4 bg-zinc-950/70 border border-zinc-800/80 rounded-xs">
                <div className="text-xs font-tech text-[#ff2e47] uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" />
                  <span>Unidade Curricular Complementar:</span>
                </div>
                <div className="font-tactical font-bold text-sm text-white uppercase mb-1">
                  Processos Gerenciais — Administração e Integração de Processos e Qualidade
                </div>
                <p className="font-body text-xs text-zinc-400 leading-relaxed">
                  {isPt
                    ? 'Esta unidade complementa a formação técnica: une meu conhecimento em TI à compreensão de gestão e administração, o que me permite traduzir demandas de negócio em soluções de software e enxergar processos, qualidade e resultados além do código.'
                    : 'Bridges raw IT knowledge with corporate management, enabling me to translate business requirements into software architectures with process quality.'}
                </p>
              </div>
            </div>
          </div>

          {/* Degree 2: MBA HSMu */}
          <div className="p-6 sm:p-8 bg-[#0b0c12] border border-zinc-800 rounded-xs flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-red-600/10 to-transparent pointer-events-none" />

            <div>
              <div className="flex items-center justify-between text-xs font-tech text-[#ff334b] tracking-widest uppercase mb-2">
                <span>PÓS-GRADUAÇÃO / LATO SENSU</span>
                <span className="text-zinc-500">HSMu</span>
              </div>

              <h3 className="font-display text-2xl sm:text-3xl font-bold text-white uppercase tracking-wide mb-3">
                MBA em Gestão Empresarial e Estratégia Competitiva
              </h3>

              <div className="text-xs font-tech text-zinc-400 mb-4">
                HSM University (HSMu) · Início após o ADS
              </div>

              <p className="font-body text-xs sm:text-sm text-zinc-300 leading-relaxed mb-6">
                {isPt
                  ? 'Foco: gestão empresarial, Business Agility, inteligência competitiva, liderança corporativa, gestão administrativa e tomada de decisão orientada a dados.'
                  : 'Focus: enterprise governance, Business Agility, competitive intelligence, corporate leadership, administrative management, and data-driven strategic decision-making.'}
              </p>

              <div className="grid grid-cols-2 gap-3 mb-6 font-tech text-xs">
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xs">
                  <span className="text-[#ff1e38] block font-bold mb-0.5">BUSINESS AGILITY</span>
                  <span className="text-zinc-400 text-[11px]">Adaptação ágil a dinâmicas de mercado</span>
                </div>
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xs">
                  <span className="text-[#ff1e38] block font-bold mb-0.5">COMPETITIVE INTEL</span>
                  <span className="text-zinc-400 text-[11px]">Análise de mercado e posicionamento</span>
                </div>
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xs">
                  <span className="text-[#ff1e38] block font-bold mb-0.5">LEADERSHIP</span>
                  <span className="text-zinc-400 text-[11px]">Gestão de metas e liderança remota</span>
                </div>
                <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xs">
                  <span className="text-[#ff1e38] block font-bold mb-0.5">DATA DECISION</span>
                  <span className="text-zinc-400 text-[11px]">Modelos analíticos orientados a dados</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-zinc-900/50 border border-zinc-800 text-[11px] font-tech text-zinc-400 flex items-center justify-between">
              <span>HSM UNIVERSITY // EXEC ED</span>
              <span className="text-green-400">ENROLLMENT PLANNED POST-ADS</span>
            </div>
          </div>

        </div>

        {/* Áreas de Interesse (Section from user prompt) */}
        <div>
          <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.25em] uppercase mb-4">
            <Target className="w-3.5 h-3.5" />
            <span>{isPt ? 'ÁREAS DE INTERESSE // FOCUS DOMAINS' : 'FOCUS DOMAINS'}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {areasOfInterest.map((a, idx) => (
              <div
                key={idx}
                className="p-4 bg-[#090a10] border border-zinc-800/80 hover:border-red-500/40 rounded-xs transition-colors flex flex-col justify-between"
              >
                <div className="text-[10px] font-tech text-zinc-500 tracking-widest mb-2">
                  {a.code}
                </div>
                <h4 className="font-tactical text-sm sm:text-base font-bold text-white uppercase tracking-wide">
                  {a.title}
                </h4>
                <div className="mt-4 pt-2 border-t border-zinc-900 text-[10px] font-tech text-[#ff334b]">
                  STRATEGIC ALIGNMENT &rarr;
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
