'use client';

import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Crosshair, ArrowRight, Terminal, Cpu } from 'lucide-react';

interface PreloaderProps {
  onComplete: () => void;
  autostart?: boolean;
}

export default function Preloader({ onComplete, autostart = false }: PreloaderProps) {
  const [progress, setProgress] = useState(0);
  const [statusLog, setStatusLog] = useState('INITIALIZING SECURE LINK...');
  const [isWelcome, setIsWelcome] = useState(false);
  const [autoUnlockCountdown, setAutoUnlockCountdown] = useState<number | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Background animated dark-matter / red ambient energy
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Particle nodes resembling red dark-matter fluid & smoke
    const particles: Array<{
      x: number;
      y: number;
      radius: number;
      vx: number;
      vy: number;
      alpha: number;
    }> = [];

    const isHeadless =
      typeof navigator !== 'undefined' &&
      (navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent));
    const count = isHeadless ? 20 : 65;

    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * 2.5 + 1,
        vx: (Math.random() - 0.5) * 0.4,
        vy: -Math.random() * 0.6 - 0.2,
        alpha: Math.random() * 0.5 + 0.2,
      });
    }

    let time = 0;
    const render = () => {
      time += 0.01;
      ctx.fillStyle = '#060609';
      ctx.fillRect(0, 0, width, height);

      // Deep atmospheric red radial gradient centered
      const grad = ctx.createRadialGradient(
        width / 2,
        height / 2,
        50,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.7
      );
      grad.addColorStop(0, 'rgba(180, 20, 36, 0.22)');
      grad.addColorStop(0.4, 'rgba(100, 10, 20, 0.12)');
      grad.addColorStop(0.8, 'rgba(6, 6, 9, 0.95)');
      grad.addColorStop(1, '#060609');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Render floating ember nodes
      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        if (p.y < 0) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 30, 56, ${p.alpha})`;
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#ff1e38';
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Tactical boot sequence progress and automatic WELCOME transition
  useEffect(() => {
    if (autostart) {
      onComplete();
      return;
    }

    const logs = [
      { at: 15, text: 'LOADING ENTERPRISE ARCHITECTURE...' },
      { at: 35, text: 'MOUNTING TACTICAL VIEWPORT...' },
      { at: 60, text: 'SYNCHRONIZING ERP KNOWLEDGE (PROTHEUS/TASY/SENIOR)...' },
      { at: 85, text: 'ORCHESTRATING LOCAL LLM AGENTS (QWEN/OLLAMA)...' },
      { at: 100, text: 'PROTOCOLS VERIFIED // WELCOME TO ZACK STUDIOS' },
    ];

    let autoUnlockTimer: NodeJS.Timeout | null = null;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        const next = Math.min(prev + Math.floor(Math.random() * 5 + 3), 100);
        const currentLog = logs.find((l) => next <= l.at) || logs[logs.length - 1];
        setStatusLog(currentLog.text);

        if (next === 100) {
          clearInterval(timer);
          // Turn "ZACK STUDIOS" to "WELCOME"
          setIsWelcome(true);
          setStatusLog('WELCOME // ACCESS GRANTED. INITIALIZING VIEWPORT...');
          
          // Automatically unlock main page after displaying WELCOME
          autoUnlockTimer = setTimeout(() => {
            setDismissed(true);
            setTimeout(() => {
              onComplete();
            }, 600);
          }, 1600);
        }
        return next;
      });
    }, 60);

    return () => {
      clearInterval(timer);
      if (autoUnlockTimer) clearTimeout(autoUnlockTimer);
    };
  }, [autostart, onComplete]);

  const handleEnter = () => {
    setDismissed(true);
    setTimeout(() => {
      onComplete();
    }, 600);
  };

  if (dismissed) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 1 }}
        exit={{ opacity: 0, scale: 1.05 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="fixed inset-0 z-50 flex flex-col justify-between p-6 sm:p-12 bg-[#060609] text-white select-none overflow-hidden"
      >
        {/* Background Dark Matter Canvas */}
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

        {/* Diagonal Tactical Slash overlay inspired by Image 2 */}
        <div className="absolute inset-0 pointer-events-none opacity-20">
          <div className="w-[200%] h-32 bg-gradient-to-r from-transparent via-[#ff1e38] to-transparent transform -rotate-45 translate-x-[-25%] translate-y-[100%] blur-3xl" />
        </div>

        {/* Top Bar with coordinates and status */}
        <div className="relative z-10 flex justify-between items-center text-xs tracking-widest text-zinc-400 font-tech">
          <div className="flex items-center gap-3">
            <span className="inline-block w-2 h-2 bg-[#ff1e38] rounded-full shadow-[0_0_8px_#ff1e38]" />
            <span className="font-semibold text-zinc-300">ZACK ENGINE // V2.6</span>
            <span className="hidden sm:inline text-zinc-600">|</span>
            <span className="hidden sm:inline text-zinc-400">LAT: -22.9068 // LON: -43.1729</span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-red-950/40 border border-red-500/30 text-red-400 rounded-xs">
              <Shield className="w-3 h-3 text-[#ff1e38]" />
              <span>100% REMOTE OPS</span>
            </div>
            <button
              onClick={handleEnter}
              className="text-zinc-500 hover:text-white transition-colors underline text-[11px]"
            >
              SKIP INTRO
            </button>
          </div>
        </div>

        {/* Right Vertical Watermark (DEFY THE LIMITS style from Image 2) */}
        <div className="hidden lg:block absolute right-8 top-1/2 -translate-y-1/2 rotate-90 origin-right text-[11px] font-tech tracking-[0.4em] text-zinc-600 uppercase pointer-events-none">
          DEFY THE LIMITS /// SECURE ENTERPRISE NODE
        </div>

        {/* Center Title Display Inspired directly by Image 2 (NIGHT MARKET) */}
        <div className="relative z-10 my-auto text-center flex flex-col items-center justify-center min-h-[360px] sm:min-h-[460px]">
          {/* Subtle date/coordinates banner above */}
          <div className="flex items-center gap-3 text-xs tracking-[0.3em] text-[#ff334b] font-tech mb-3">
            <span>04 // 06 // 22</span>
            <span className="text-zinc-600">///</span>
            <span>04 // 19 // 26</span>
          </div>

          {!isWelcome ? (
            /* ZACK STUDIOS State */
            <motion.div
              key="zack-studios"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="relative flex flex-col items-center"
            >
              {/* Top Word */}
              <h1 className="font-display text-8xl sm:text-9xl md:text-[14rem] leading-[0.8] font-bold text-[#ff1e38] tracking-tighter drop-shadow-[0_0_40px_rgba(255,30,56,0.5)]">
                ZACK
              </h1>

              {/* Center Tactical Diamond Emblem */}
              <div className="my-[-1rem] sm:my-[-2.2rem] z-20 w-10 h-10 sm:w-14 sm:h-14 border-2 border-[#ff1e38] bg-[#07070b] flex items-center justify-center shadow-[0_0_20px_#ff1e38] transform rotate-45">
                <div className="w-4 h-4 bg-[#ff1e38] transform -rotate-45" />
              </div>

              {/* Bottom Word */}
              <h1 className="font-display text-8xl sm:text-9xl md:text-[14rem] leading-[0.8] font-bold text-[#ff1e38] tracking-tighter drop-shadow-[0_0_40px_rgba(255,30,56,0.5)]">
                STUDIOS
              </h1>

              {/* Technical Sub-line with Diamond Dividers */}
              <div className="mt-6 flex items-center justify-center gap-3 text-xs sm:text-sm font-tech tracking-[0.25em] text-zinc-400">
                <span className="h-[1px] w-8 sm:w-16 bg-gradient-to-r from-transparent to-[#ff1e38]" />
                <span className="text-zinc-200 uppercase">IT & ADMIN OPS // STRATEGIC ARCHITECTURE</span>
                <span className="h-[1px] w-8 sm:w-16 bg-gradient-to-l from-transparent to-[#ff1e38]" />
              </div>
            </motion.div>
          ) : (
            /* WELCOME State - Transforms immediately and holds before auto-unlocking */
            <motion.div
              key="welcome-banner"
              initial={{ opacity: 0, scale: 0.9, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.4, ease: 'easeOut' }}
              className="relative flex flex-col items-center"
            >
              {/* Tactical Status Pill */}
              <div className="flex items-center gap-2 px-3.5 py-1 bg-red-950/70 border border-red-500/50 text-[#ff334b] text-xs font-tech tracking-[0.25em] uppercase mb-4 shadow-[0_0_20px_rgba(255,30,56,0.5)]">
                <span className="w-2 h-2 bg-[#ff1e38] rounded-full animate-ping" />
                <span>AUTHENTICATION CONFIRMED</span>
              </div>

              {/* Giant Glowing WELCOME */}
              <h1 className="font-display text-8xl sm:text-9xl md:text-[13rem] lg:text-[15rem] leading-[0.82] font-bold text-white tracking-tight drop-shadow-[0_0_60px_rgba(255,30,56,0.85)] uppercase">
                WEL<span className="text-[#ff1e38]">COME</span>
              </h1>

              {/* Center Tactical Diamond Emblem */}
              <div className="my-[-0.6rem] sm:my-[-1.2rem] z-20 w-10 h-10 sm:w-14 sm:h-14 border-2 border-[#ff1e38] bg-[#07070b] flex items-center justify-center shadow-[0_0_25px_#ff1e38] transform rotate-45">
                <div className="w-4 h-4 bg-[#ff1e38] transform -rotate-45" />
              </div>

              {/* Sub-line acknowledging unlock */}
              <div className="mt-8 flex items-center justify-center gap-3 text-xs sm:text-sm font-tech tracking-[0.25em] text-zinc-300">
                <span className="h-[1px] w-8 sm:w-20 bg-gradient-to-r from-transparent to-[#ff1e38]" />
                <span className="text-white uppercase font-bold tracking-[0.3em]">
                  [ ACCESS GRANTED // INICIANDO EXPERIÊNCIA ]
                </span>
                <span className="h-[1px] w-8 sm:w-20 bg-gradient-to-l from-transparent to-[#ff1e38]" />
              </div>
            </motion.div>
          )}
        </div>

        {/* Bottom Loading Progress & Status Bar */}
        <div className="relative z-10 w-full max-w-3xl mx-auto flex flex-col gap-3 font-tech">
          <div className="flex justify-between items-end text-xs">
            <div className="flex items-center gap-2 text-zinc-400">
              <Terminal className="w-3.5 h-3.5 text-[#ff1e38]" />
              <span className="text-zinc-300 font-mono text-[11px] sm:text-xs tracking-wider">
                {statusLog}
              </span>
            </div>
            <div className="text-right">
              <span className="font-display text-2xl sm:text-3xl font-bold text-white tracking-wider">
                {progress}%
              </span>
            </div>
          </div>

          {/* Glowing Red Progress Bar */}
          <div className="relative w-full h-1.5 bg-zinc-900 border border-zinc-800 rounded-none overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[#990d1f] via-[#ff1e38] to-[#ff4760] shadow-[0_0_15px_#ff1e38]"
              style={{ width: `${progress}%` }}
              transition={{ ease: 'linear' }}
            />
          </div>

          {/* Bottom Status / Auto-unlock state */}
          <div className="flex justify-center mt-3">
            {isWelcome ? (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 text-green-400 font-tech text-xs tracking-widest uppercase py-2"
              >
                <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_#22c55e]" />
                <span>DESBLOQUEANDO PORTFÓLIO AUTOMATICAMENTE...</span>
              </motion.div>
            ) : (
              <div className="flex items-center gap-2 text-zinc-600 text-xs tracking-widest uppercase py-2">
                <Cpu className="w-3.5 h-3.5 animate-spin text-[#ff1e38]" />
                <span>CARREGANDO INFRAESTRUTURA...</span>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
