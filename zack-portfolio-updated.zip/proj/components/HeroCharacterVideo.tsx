'use client';

import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import {
  GAZE_POSES,
  GAZE_TUNING,
  GAZE_VIDEO,
  frameIndex,
  frameTime,
  getPose,
  pickPose,
  pointerToGaze,
  tweenDuration,
  type Gaze,
  type GazePose,
} from '@/lib/gaze';

/**
 * Personagem em vídeo que acompanha o cursor com o olhar.
 * Substitui o antigo objeto 3D (Three.js) na mesma posição da seção, preservando
 * o contêiner, o brilho de fundo e as marcações HUD.
 *
 * Os momentos do vídeo usados para cada direção ficam em `lib/gaze.ts` (GAZE_POSES).
 * O GSAP tem um único tween ativo sobre `proxy.t` (tempo alvo do vídeo); a cada tick
 * do ticker do GSAP o quadro correspondente é pedido ao <video>, sem seeks concorrentes.
 */
export default function HeroCharacterVideo() {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRefs = useRef<Array<HTMLVideoElement | null>>([null, null]);
  const [debug, setDebug] = useState<string | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    const [videoA, videoB] = videoRefs.current;
    if (!container || !videoA || !videoB) return;

    const videos = [videoA, videoB];
    const showDebug =
      typeof window !== 'undefined' && new URLSearchParams(window.location.search).has('gazedebug');

    const prefersReducedMotion =
      typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const rest = getPose(GAZE_VIDEO.restPoseId);
    let disposed = false;
    let active = 0; // índice do <video> visível
    let pose: GazePose = rest; // pose alvo atual
    let hopping = false;
    let pendingPose: GazePose | null = null;
    let inView = true;
    let shownFrame = -1;
    let tween: gsap.core.Tween | null = null;
    let rafId = 0;
    let gaze: Gaze = { yaw: 0, pitch: 0 };

    // Tempo alvo do vídeo (segundos), animado pelo GSAP.
    const proxy = { t: rest.t };

    const report = () => {
      if (showDebug) setDebug(`${pose.id} · t=${proxy.t.toFixed(2)}s`);
    };

    const seekActive = (force = false) => {
      const v = videos[active];
      const f = frameIndex(proxy.t);
      if (!force && (f === shownFrame || v.seeking)) return; // um seek por vez, sempre o mais recente
      if (v.readyState < 1) return; // metadados ainda não carregados
      shownFrame = f;
      v.currentTime = frameTime(proxy.t);
    };

    const onTick = () => {
      if (!disposed) seekActive();
    };

    const applyInitialFrame = () => {
      shownFrame = -1;
      seekActive(true);
    };

    // ---- Transições ---------------------------------------------------------

    const scrubTo = (next: GazePose) => {
      tween?.kill();
      tween = gsap.to(proxy, {
        t: next.t,
        duration: tweenDuration(proxy.t, next.t),
        ease: 'power2.inOut',
        overwrite: true,
        onUpdate: report,
        onComplete: () => {
          tween = null;
        },
      });
    };

    const waitSeeked = (v: HTMLVideoElement) =>
      new Promise<void>((resolve) => {
        let done = false;
        const finish = () => {
          if (done) return;
          done = true;
          v.removeEventListener('seeked', finish);
          window.clearTimeout(timer);
          resolve();
        };
        const timer = window.setTimeout(finish, GAZE_TUNING.hopSeekTimeoutMs);
        v.addEventListener('seeked', finish);
      });

    const hopTo = async (next: GazePose) => {
      hopping = true;
      tween?.kill();
      tween = null;

      const from = videos[active];
      const to = videos[1 - active];
      to.currentTime = frameTime(next.t);
      await waitSeeked(to);
      if (disposed) return;

      // Passa o controle do scrub para o vídeo reserva e faz o crossfade.
      proxy.t = next.t;
      shownFrame = frameIndex(next.t);
      active = 1 - active;
      to.style.zIndex = '2';
      from.style.zIndex = '1';
      gsap.killTweensOf([from, to]);
      gsap.fromTo(to, { opacity: 0 }, { opacity: 1, duration: GAZE_TUNING.crossfadeSeconds, ease: 'power1.out' });
      gsap.to(from, {
        opacity: 0,
        duration: GAZE_TUNING.crossfadeSeconds,
        ease: 'power1.in',
        onComplete: () => {
          hopping = false;
          report();
          if (pendingPose && pendingPose !== pose) {
            const queued = pendingPose;
            pendingPose = null;
            goTo(queued);
          }
          pendingPose = null;
        },
      });
    };

    const goTo = (next: GazePose) => {
      if (disposed || next === pose) return;
      if (hopping) {
        pendingPose = next;
        return;
      }
      const sameSegment = next.segment === pose.segment;
      pose = next;
      if (sameSegment) scrubTo(next);
      else void hopTo(next);
    };

    // ---- Cursor → olhar -----------------------------------------------------

    const retarget = () => {
      rafId = 0;
      if (disposed || !inView) return;
      goTo(pickPose(gaze, pose, GAZE_POSES, GAZE_TUNING));
    };

    const schedule = () => {
      if (!rafId) rafId = requestAnimationFrame(retarget);
    };

    const onPointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ny = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      gaze = pointerToGaze(nx, ny);
      schedule();
    };

    const onPointerLeaveWindow = (e: MouseEvent) => {
      if (e.relatedTarget === null) {
        gaze = { yaw: 0, pitch: 0 };
        schedule();
      }
    };

    // ---- Ciclo de vida ------------------------------------------------------

    videos.forEach((v) => {
      v.muted = true;
      v.defaultMuted = true;
      v.playsInline = true;
      v.pause();
    });

    const onMeta = () => applyInitialFrame();
    videoA.addEventListener('loadedmetadata', onMeta);
    if (videoA.readyState >= 1) applyInitialFrame();

    // Reduz movimento: mostra apenas o quadro de repouso, sem rastrear o cursor.
    let observer: IntersectionObserver | null = null;
    if (!prefersReducedMotion) {
      gsap.ticker.add(onTick);
      window.addEventListener('pointermove', onPointerMove, { passive: true });
      document.addEventListener('mouseout', onPointerLeaveWindow);
      if (typeof IntersectionObserver !== 'undefined') {
        observer = new IntersectionObserver(
          ([entry]) => {
            inView = entry.isIntersecting;
          },
          { threshold: 0.05 }
        );
        observer.observe(container);
      }
    }
    report();

    return () => {
      disposed = true;
      if (rafId) cancelAnimationFrame(rafId);
      tween?.kill();
      gsap.ticker.remove(onTick);
      gsap.killTweensOf([proxy, ...videos]);
      window.removeEventListener('pointermove', onPointerMove);
      document.removeEventListener('mouseout', onPointerLeaveWindow);
      videoA.removeEventListener('loadedmetadata', onMeta);
      observer?.disconnect();
      videos.forEach((v) => v.pause());
    };
  }, []);

  const videoClass = 'absolute inset-0 w-full h-full object-cover select-none pointer-events-none';
  const fadeMask =
    'linear-gradient(to right, transparent, #000 9%, #000 91%, transparent), linear-gradient(to bottom, transparent, #000 8%, #000 90%, transparent)';

  return (
    <div className="relative w-full h-[380px] sm:h-[480px] lg:h-[580px] flex items-center justify-center">
      {/* Área de interação: o cursor é normalizado em relação a este contêiner */}
      <div
        ref={containerRef}
        data-testid="hero-character-video"
        className="w-full h-full relative flex items-center justify-center"
        style={{ containerType: 'size' }}
      >
        <div
          className="relative"
          style={{
            width: `min(100%, calc(100cqh * ${GAZE_VIDEO.aspect}))`,
            aspectRatio: `${GAZE_VIDEO.aspect}`,
            WebkitMaskImage: fadeMask,
            maskImage: fadeMask,
            WebkitMaskComposite: 'source-in',
            maskComposite: 'intersect',
          }}
        >
          {[0, 1].map((i) => (
            <video
              key={i}
              ref={(el) => {
                videoRefs.current[i] = el;
              }}
              className={videoClass}
              style={{ opacity: i === 0 ? 1 : 0, zIndex: i === 0 ? 2 : 1 }}
              poster={i === 0 ? GAZE_VIDEO.poster : undefined}
              preload="auto"
              muted
              playsInline
              disablePictureInPicture
              aria-hidden="true"
              tabIndex={-1}
            >
              {GAZE_VIDEO.sources.map((s) => (
                <source key={s.src} src={s.src} type={s.type} />
              ))}
            </video>
          ))}
        </div>
      </div>

      {/* Atmospheric Crimson Radial Glow underneath */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[280px] sm:w-[420px] h-[280px] sm:h-[420px] bg-[#ff1e38]/15 rounded-full blur-[80px] pointer-events-none -z-10" />

      {/* Tactical HUD Corner Marks (matching Image 1 aesthetic) */}
      <div className="absolute top-4 left-4 flex items-center gap-1.5 text-[10px] font-tech text-red-400/80 tracking-widest pointer-events-none">
        <span className="w-1.5 h-1.5 bg-[#ff1e38]" />
        <span>SYS_VIDEO // OPERATOR_CORE</span>
      </div>

      <div className="absolute bottom-4 right-4 text-[10px] font-tech text-zinc-500 tracking-widest pointer-events-none">
        <span>INTERACTIVE // EYES FOLLOW CURSOR</span>
      </div>

      {debug && (
        <div className="absolute top-4 right-4 text-[10px] font-tech text-emerald-400 tracking-widest pointer-events-none">
          {debug}
        </div>
      )}
    </div>
  );
}
