'use client';

import React, { useState } from 'react';
import {
  Brain,
  Terminal,
  Cpu,
  Layers,
  Sparkles,
  Play,
  RotateCcw,
  CheckCircle,
  FileSpreadsheet,
  Lock,
  GitBranch,
} from 'lucide-react';
import { AI_TECH_STACK } from '@/lib/portfolio';

interface AiSpecializationSectionProps {
  currentLang: 'pt' | 'en';
}

export default function AiSpecializationSection({ currentLang }: AiSpecializationSectionProps) {
  const isPt = currentLang === 'pt';

  // Interactive Gotham Local AI Assistant demo state
  const [simQuery, setSimQuery] = useState<'financial' | 'bottleneck' | 'contract'>('financial');
  const [simRunning, setSimRunning] = useState(false);
  const [simOutput, setSimOutput] = useState<string | null>(null);

  const runGothamDemo = (type: 'financial' | 'bottleneck' | 'contract') => {
    setSimQuery(type);
    setSimRunning(true);
    setSimOutput(null);

    setTimeout(() => {
      if (type === 'financial') {
        setSimOutput(
          JSON.stringify(
            {
              status: 'SUCCESS',
              model: 'Qwen 2.5 (Local via Ollama)',
              privacy: '100% AIR-GAPPED // ZERO EXTERNAL TRANSMISSION',
              input_data: 'dre_operacional_q3.csv (3.420 linhas)',
              sintese_executiva: {
                faturamento_bruto: 'R$ 742.000,00',
                custo_operacional: 'R$ 518.200,00',
                margem_liquida: '30.16%',
                anomalia_detectada: 'Linha 412: Desvio de 18% em despesas de hospedagem/cloud redundantes.',
                recomendacao_estrategica:
                  'Consolidar instâncias AWS/GCP e renegociar contratos de fornecedores de software para estancar R$ 24.000/mês.',
              },
            },
            null,
            2
          )
        );
      } else if (type === 'bottleneck') {
        setSimOutput(
          JSON.stringify(
            {
              status: 'SUCCESS',
              model: 'Qwen 2.5 (Local via LM Studio)',
              privacy: '100% SECURE LOCAL NODE',
              input_data: 'chamados_ti_producao.csv (1.180 tickets)',
              diagnostico: {
                gargalo_critico: 'Parametrização contábil no módulo SIGAFAT (Protheus)',
                tempo_medio_resolucao: '4.8 horas (meta < 1.5h)',
                acao_corretiva:
                  'Implementar script de validação fiscal automatizado via API REST antes da emissão de notas fiscais em lote.',
                ganho_estimado: 'Redução de 62% no volume de reaberturas de tickets.',
              },
            },
            null,
            2
          )
        );
      } else {
        setSimOutput(
          JSON.stringify(
            {
              status: 'SUCCESS',
              model: 'Qwen 2.5 + Claude Tool Use Architecture',
              privacy: 'LOCAL PRE-PROCESSING VERIFIED',
              input_data: 'minuta_contrato_fornecedor_internacional.pdf',
              parecer_juridico_administrativo: {
                clausula_risco: 'Cláusula 14.3: Foro arbitral exclusivo sem limitação de responsabilidade civil.',
                conflito_normativo: 'Incompatível com os padrões de compliance e LGPD definidos no regulamento interno.',
                proposta_redacao:
                  'Substituir por limite indenizatório fixado em 100% do valor do contrato com mediação preliminar.',
              },
            },
            null,
            2
          )
        );
      }
      setSimRunning(false);
    }, 700);
  };

  return (
    <section id="ia" className="relative py-20 lg:py-28 bg-[#07070c] border-b border-zinc-900">
      {/* Background Ambient Glow */}
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-[#ff1e38]/8 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col gap-2 mb-14">
          <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.3em] uppercase">
            <span className="w-1.5 h-1.5 bg-[#ff1e38]" />
            <span>AI // SPECIALIZATION</span>
          </div>
          <h2 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold uppercase text-white tracking-tight">
            {isPt ? 'ESPECIALIZAÇÃO EM IA' : 'AI SPECIALIZATION'}
          </h2>
          <p className="font-tactical text-lg sm:text-xl text-zinc-400 max-w-3xl">
            {isPt
              ? 'LLMs, modelos locais e IA generativa aplicados a decisão e dados.'
              : 'Local LLMs, autonomous agents, and generative AI applied to high-stakes decisions and data engineering.'}
          </p>
        </div>

        {/* Narrative Intro */}
        <div className="p-6 bg-[#0b0c14] border border-zinc-800 rounded-xs mb-12 text-zinc-300 font-body text-base leading-relaxed border-l-4 border-l-[#ff1e38]">
          {isPt
            ? 'Minha especialização é orientada a LLMs, modelos de linguagem locais e inteligência artificial generativa, com foco em agentes, automações e sistemas de apoio à tomada de decisão e ao tratamento de dados.'
            : 'My specialization is centered on local LLMs, private inference runtimes, and generative AI—focusing on autonomous agents, workflow automation, decision-support systems, and rigorous data preparation.'}
        </div>

        {/* 4 Pillars of AI Specialization */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          
          {/* Card 1: Modelos Locais */}
          <div className="p-6 bg-[#090a12] border border-zinc-800 rounded-xs">
            <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-widest uppercase mb-3">
              <Cpu className="w-4 h-4" />
              <span>{isPt ? 'Modelos Locais & LLMs' : 'Local Models & LLMs'}</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {AI_TECH_STACK.localModels.map((item) => (
                <span
                  key={item}
                  className="px-2.5 py-1 text-xs font-tech bg-zinc-900 border border-zinc-800 text-zinc-200 rounded-xs"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>

          {/* Card 2: Agentes & Orquestração */}
          <div className="p-6 bg-[#090a12] border border-zinc-800 rounded-xs">
            <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-widest uppercase mb-3">
              <Brain className="w-4 h-4" />
              <span>{isPt ? 'Agentes & Orquestração' : 'Agents & Orchestration'}</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {AI_TECH_STACK.orchestration.map((item) => (
                <span
                  key={item}
                  className="px-2.5 py-1 text-xs font-tech bg-zinc-900 border border-zinc-800 text-zinc-200 rounded-xs"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>

          {/* Card 3: IA Generativa & ML */}
          <div className="p-6 bg-[#090a12] border border-zinc-800 rounded-xs">
            <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-widest uppercase mb-3">
              <Sparkles className="w-4 h-4" />
              <span>{isPt ? 'IA Generativa & ML' : 'GenAI & Machine Learning'}</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {AI_TECH_STACK.generative.map((item) => (
                <span
                  key={item}
                  className="px-2.5 py-1 text-xs font-tech bg-zinc-900 border border-zinc-800 text-zinc-200 rounded-xs"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>

          {/* Card 4: Em Aprofundamento */}
          <div className="p-6 bg-[#090a12] border border-zinc-800 rounded-xs">
            <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-widest uppercase mb-3">
              <Layers className="w-4 h-4" />
              <span>{isPt ? 'Em Aprofundamento' : 'Advanced Deepening'}</span>
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-44 overflow-y-auto pr-1">
              {AI_TECH_STACK.deepening.map((item) => (
                <span
                  key={item}
                  className="px-2 py-0.5 text-[11px] font-tech bg-zinc-900/80 border border-zinc-800/80 text-zinc-300 rounded-xs"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>

        </div>

        {/* Featured Project Spotlight: Gotham Decision AI */}
        <div className="p-6 sm:p-10 bg-[#090a10] border border-red-500/40 red-glow-subtle rounded-xs relative overflow-hidden">
          <div className="flex flex-col lg:flex-row justify-between gap-6 mb-8 pb-6 border-b border-zinc-800">
            <div>
              <div className="flex items-center gap-2 text-xs font-tech text-[#ff2e47] tracking-[0.25em] uppercase mb-1">
                <span className="w-2 h-2 bg-[#ff1e38] rounded-full animate-pulse" />
                <span>{isPt ? 'PROJETO EM DESTAQUE // EM DESENVOLVIMENTO' : 'FEATURED ARCHITECTURE // IN DEVELOPMENT'}</span>
              </div>
              <h3 className="font-display text-3xl sm:text-4xl font-bold text-white uppercase tracking-wide">
                Gotham — Assistente Local de Apoio à Decisão com LLMs
              </h3>
              <p className="font-body text-xs sm:text-sm text-zinc-400 mt-2 max-w-3xl leading-relaxed">
                {isPt
                  ? 'Agente de IA executado localmente, com modelos Qwen servidos por Ollama ou LM Studio, que recebe dados operacionais (planilhas e CSV), faz o tratamento e a organização das informações e gera análises e recomendações para apoiar decisões de gestão, sem enviar dados a serviços externos.'
                  : 'Locally deployed AI agent with Qwen models served via Ollama or LM Studio. Ingests operational CSV data, sanitizes schemas, and outputs strategic decision recommendations without third-party cloud data transmission.'}
              </p>
            </div>

            {/* Privacy Badge */}
            <div className="flex items-center gap-2 px-3.5 py-2 bg-red-950/40 border border-red-500/30 text-xs font-tech text-red-300 rounded-xs h-fit self-start">
              <Lock className="w-4 h-4 text-[#ff1e38]" />
              <span>100% PRIVATE AIR-GAPPED</span>
            </div>
          </div>

          {/* Gotham Architecture Pillars */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
            <div className="p-4 bg-zinc-950/70 border border-zinc-800 rounded-xs">
              <div className="text-[#ff334b] font-tech text-xs tracking-wider mb-1">01 // DATA CLEANSING</div>
              <div className="font-tactical text-base font-bold text-white uppercase mb-1">
                {isPt ? 'Tratamento & Padronização' : 'Data Sanitization & Hygiene'}
              </div>
              <p className="font-body text-xs text-zinc-400">
                {isPt
                  ? 'Tratamento e padronização de dados antes da análise, para que o modelo trabalhe com informação limpa e consistente.'
                  : 'Pre-flight data normalization ensuring models operate on clean, deduplicated, and consistent schemas.'}
              </p>
            </div>

            <div className="p-4 bg-zinc-950/70 border border-zinc-800 rounded-xs">
              <div className="text-[#ff334b] font-tech text-xs tracking-wider mb-1">02 // TOOL ORCHESTRATION</div>
              <div className="font-tactical text-base font-bold text-white uppercase mb-1">
                {isPt ? 'Agentes Orquestrados via API' : 'Tool-Using Local Agents'}
              </div>
              <p className="font-body text-xs text-zinc-400">
                {isPt
                  ? 'Agentes orquestrados com ferramentas, integrando a interface web ao modelo local por uma API em Node.js.'
                  : 'Autonomous tool orchestration connecting Next.js interfaces to local model nodes via optimized Node.js APIs.'}
              </p>
            </div>

            <div className="p-4 bg-zinc-950/70 border border-zinc-800 rounded-xs">
              <div className="text-[#ff334b] font-tech text-xs tracking-wider mb-1">03 // CI/CD & EVALS</div>
              <div className="font-tactical text-base font-bold text-white uppercase mb-1">
                {isPt ? 'Testes & Versionamento' : 'Automated Tests & Evals'}
              </div>
              <p className="font-body text-xs text-zinc-400">
                {isPt
                  ? 'Testes automatizados do fluxo e validação das respostas do modelo, com versionamento no Git e GitHub.'
                  : 'Automated test suite validating deterministic model responses with git version control.'}
              </p>
            </div>
          </div>

          {/* Interactive Simulation Terminal for Gotham */}
          <div className="p-5 bg-black/90 border border-zinc-800 rounded-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4 pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2 text-xs font-tech text-zinc-300">
                <Terminal className="w-4 h-4 text-[#ff1e38]" />
                <span className="font-bold text-white">GOTHAM LIVE DEMO CONSOLE</span>
                <span className="text-zinc-600">|</span>
                <span className="text-zinc-400">SELECT DATASET TO RUN LOCAL INFERENCE:</span>
              </div>

              {/* Sample Triggers */}
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => runGothamDemo('financial')}
                  disabled={simRunning}
                  className={`px-3 py-1.5 text-xs font-tech uppercase rounded-xs transition-colors cursor-pointer flex items-center gap-1.5 ${
                    simQuery === 'financial' && simOutput
                      ? 'bg-[#ff1e38] text-white'
                      : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800'
                  }`}
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>DRE Financeira (CSV)</span>
                </button>

                <button
                  onClick={() => runGothamDemo('bottleneck')}
                  disabled={simRunning}
                  className={`px-3 py-1.5 text-xs font-tech uppercase rounded-xs transition-colors cursor-pointer flex items-center gap-1.5 ${
                    simQuery === 'bottleneck' && simOutput
                      ? 'bg-[#ff1e38] text-white'
                      : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800'
                  }`}
                >
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Gargalos de TI / ERP</span>
                </button>

                <button
                  onClick={() => runGothamDemo('contract')}
                  disabled={simRunning}
                  className={`px-3 py-1.5 text-xs font-tech uppercase rounded-xs transition-colors cursor-pointer flex items-center gap-1.5 ${
                    simQuery === 'contract' && simOutput
                      ? 'bg-[#ff1e38] text-white'
                      : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800'
                  }`}
                >
                  <GitBranch className="w-3.5 h-3.5" />
                  <span>Auditoria Jurídica</span>
                </button>
              </div>
            </div>

            {/* Terminal Screen Output */}
            <div className="bg-[#050508] p-4 rounded-xs border border-zinc-900 font-mono text-xs text-zinc-300 min-h-[160px] overflow-x-auto">
              {simRunning ? (
                <div className="flex items-center gap-2 text-[#ff334b] py-8 justify-center">
                  <Cpu className="w-4 h-4 animate-spin" />
                  <span>[QWEN LOCAL RUNTIME] SANITIZANDO DADOS E EXECUTANDO AVALIAÇÃO...</span>
                </div>
              ) : simOutput ? (
                <pre className="text-green-400 whitespace-pre-wrap">{simOutput}</pre>
              ) : (
                <div className="text-zinc-500 py-6 text-center">
                  Clique em um dos datasets acima para rodar a simulação do motor local Gotham.
                </div>
              )}
            </div>

            {/* Stack Tags */}
            <div className="mt-4 pt-3 border-t border-zinc-900 flex flex-wrap items-center justify-between gap-2 text-xs font-tech text-zinc-400">
              <div className="flex flex-wrap gap-2">
                {['Qwen', 'Ollama', 'LM Studio', 'Node.js', 'Next.js', 'React', 'Git / GitHub', 'Testes automatizados'].map((t) => (
                  <span key={t} className="px-2 py-0.5 bg-zinc-900 border border-zinc-800 rounded-xs text-zinc-300">
                    {t}
                  </span>
                ))}
              </div>
              <span className="text-[#ff1e38] font-bold">AIR-GAPPED ARCHITECTURE</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
